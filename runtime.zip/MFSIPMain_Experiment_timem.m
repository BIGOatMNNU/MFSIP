%%% MFSIPMain_Experiment
% create by ZiLng Lin
% 2023-12-20
%% MFSIPMain.m+fs+���ٲ���
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP_Fast';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 2:2%length(str_train_name)
%     if(i == 6 || i == 10)
%         continue;
%     end
%     %0 load
%     mat_name = str_train_name{i};
%     load (mat_name);
%     
%     %1 algorithm
%     alpha = 0.1;
%     beta = 0.1;
%     [feature_select, time, objDraw] = MFSIPMain(data_array, tree, alpha, beta);
% 
%     vTime = time;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = feature_select;
%     vAlpha = alpha;
%     vBeta = beta;
%     vObj = objDraw;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB', 'vAlpha', 'vBeta', 'vObj');
% end
% 
% %% ����ͼ alpha(0.1)+beta(0.1)+���ٲ���
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_MFSIP_Fast_Bridges.mat','fs_result_MFSIP_Fast_DD.mat','fs_result_MFSIP_Fast_CLEF.mat','fs_result_MFSIP_Fast_VOC.mat','fs_result_MFSIP_Fast_News20g.mat','fs_result_MFSIP_Fast_F194.mat','fs_result_MFSIP_Fast_ILSVRC65.mat','fs_result_MFSIP_Fast_Sun.mat','fs_result_MFSIP_Fast_Cifar100.mat','fs_result_MFSIP_Fast_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% 
% for i = 2:2%length(str_mat_name)-1
%     if(i == 6 || i == 10)
%         continue;
%     end
%     %0 load
%     mat_name = str_mat_name{i};
%     load (mat_name);
% 
%     %1 algorithm
%     objDraw = vObj;
% 
%     %3 ������ͼ
%     fontsize = 20;
%     figure1 = figure('Color',[1 1 1]);
%     axes1 = axes('Parent',figure1,'FontSize',fontsize,'FontName','Times New Roman');
% 
%     plot(objDraw,'LineWidth',4,'Color',[0 0 1]);
%     if(i == 5)
%         xlim(axes1,[0.8 30]);
%     else
%         xlim(axes1,[0.8 10]);
%     end
%     %ylim(axes1,[16000,36000]);%Cifar
%     %set(gca,'yscale','log') 
%     set(gca,'FontName','Times New Roman','FontSize',fontsize);
%     xlabel(['Iteration number']);
%     ylabel('Objective function value');
% 
%     fileName_result = [int2str(7),'_',int2str(i),'_',algorithmName, '_fig_', str_data_name{i}];
%     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     close(figure1);
% end
% 
% %% MFSIPMain.m+acc(+RF)�����+���ٲ���
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_MFSIP_Fast_Bridges.mat','fs_result_MFSIP_Fast_DD.mat','fs_result_MFSIP_Fast_CLEF.mat','fs_result_MFSIP_Fast_VOC.mat','fs_result_MFSIP_Fast_News20g.mat','fs_result_MFSIP_Fast_F194.mat','fs_result_MFSIP_Fast_ILSVRC65.mat','fs_result_MFSIP_Fast_Sun.mat','fs_result_MFSIP_Fast_Cifar100.mat','fs_result_MFSIP_Fast_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP_Fast';
% filePath = '/Users/lindashuai/Documents/MATLAB/';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 2:2%length(str_mat_name)
%     if(i == 6 || i == 10)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime;
%     vSamples = size(data_array, 1);
%     labelIndex = size(data_array, 2);
%     numFeature = labelIndex - 1;
%     numSeleted = round(numFeature * selectNum(i));
%     vReducedFeaturesB = vReducedFeaturesB{end}(1:numSeleted);
%     vFeatureNum = length(vReducedFeaturesB);
%     
%     %1 save
%     data = data_array(:,[vReducedFeaturesB', labelIndex]);
%     fold = 10;
%     method1 = 'KNN';
%     [acc_mean,acc_std, label1,testL1,len, accu_m] = crossvalidate_MLIP(data, fold, method1);
%     [F_LCA, F_A, TIE] = EvaHier_HierarchicalLCAPrecisionAndRecall_MLIP(testL1, label1, tree);
%     vac_KNN = acc_mean;
%     vF_1_KNN = F_A;
%     vF_LCA_KNN = F_LCA;
%     vTIE_KNN = TIE;
% 
%     method2 = 'LSVM';
%     [acc_mean_SVM,acc_std_SVM, label1_SVM,testL1_SVM,len_SVM, accu_m_SVM] = crossvalidate_MLIP(data, fold, method2);
%     [F_LCA_SVM, F_A_SVM, TIE_SVM] = EvaHier_HierarchicalLCAPrecisionAndRecall_MLIP(testL1_SVM, label1_SVM, tree);
%     vac_SVM = acc_mean_SVM;
%     vF_1_SVM = F_A_SVM;
%     vF_LCA_SVM = F_LCA_SVM;
%     vTIE_SVM = TIE_SVM;
%     
%     method3 = 'RF';
%     [acc_mean_RF,acc_std_RF, label1_RF,testL1_RF,len_RF, accu_m_RF] = crossvalidate_MLIP(data, fold, method3);
%     [F_LCA_RF, F_A_RF, TIE_RF] = EvaHier_HierarchicalLCAPrecisionAndRecall_MLIP(testL1_RF, label1_RF, tree);
%     vac_RF = acc_mean_RF;
%     vF_1_RF = F_A_RF;
%     vF_LCA_RF = F_LCA_RF;
%     vTIE_RF = TIE_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum');
% end

%% MFSIPMain.m+fs
% clc;
% clear All;
% 
% %1 Bridges  108*12     65*12      43*12     ���ò���
% %2 DD(use)  3625*474   3020*474   605*474   ���ò���
% %3 CLEF(use)9307*81    8368*81    939*81    ��û���� train ȫ����0    test ȫ����0 ȫ��һ��
% %4 VOC(use) 12283*1001 7178*1001  5105*1001 ���ò���
% %5 News20g  1902*26215 951*26215  951*26215
% %6 F194     8525*474   7105*474   1420*474  ���ò���
% %7 ILSVRC65 24191*4097 12346*4097 11845*4097 train ȫ����0  test ȫ����0 ȫ��һ��
% %8 Sun      67665*4097 45109*4097 22556*4097 ���ò���
% %9 Cifar100 60000*4097 50000*4097 10000*4097 train ȫ����0  test ȫ����0 ȫ��һ��
% %10 Car196                                   train ȫ����0  test ȫ����0 ȫ��һ��
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 3:3%length(str_train_name)
% %     if(i == 5)
% %         continue;
% %     end
%     %0 load
%     mat_name = str_train_name{i};
%     load (mat_name);
%     
%     %1 algorithm
%     alpha = 0.1;
%     beta = 0.1;
%     [feature_select, time, objDraw] = MFSIPMain(data_array, tree, alpha, beta);
% 
%     vTime = time;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = feature_select;
%     vAlpha = alpha;
%     vBeta = beta;
%     vObj = objDraw;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB', 'vAlpha', 'vBeta', 'vObj');
% end

%% MFSIPMain.m+fs+acc(+RF)
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_MFSIP_Bridges.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 3:3%length(str_test_name)
% %     if(i == 5)
% %         continue;
% %     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     vAlpha = vAlpha;
%     vBeta = vBeta;
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate', 'vAlpha', 'vBeta');
% end

%% tsne
%% MFSIPMain.m+fs+acc(+tsne)DAG
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_MFSIP_Bridges.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Car196.mat','fs_result_MFSIP_Eisen.mat','fs_result_MFSIP_Derisi.mat','fs_result_MFSIP_Cellcycle.mat','fs_result_MFSIP_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 14:14%length(str_test_name)
%     selectNode = [808];  % 12-3
%     for ii= 1:length(selectNode)
%         nodeIndex = selectNode(ii); % 3-9 4-5 6-5 7-7
%     %     if(i == 5)
%     %         continue;
%     %     end
%         %0 load ���Լ�+����
% %         data_test_name = str_test_name{i};
% %         load (data_test_name);
% 
%         data_train_name = str_train_name{i};
%         load (data_train_name);
%         
%         data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
%         mat_name = str_mat_name{i};
%         load (mat_name);
%         
%         vReducedFeaturesB_End = vReducedFeaturesB{nodeIndex};
%         vReducedFeaturesB_End_len = length(vReducedFeaturesB_End);
%         vFeatureNumRate = selectNum(i);
%         vFeatureNum = round(vReducedFeaturesB_End_len * vFeatureNumRate);
%         vReducedFeaturesB_Reduce_End = vReducedFeaturesB_End(1:vFeatureNum);
%         
%         %1 ��������ͼ
%     %     labels_Y = data_array(:,end);
%         [XX, Y] = creatSubTablezh_DAG_IP(data_array, DAG);
%         
% %         aaa = [];
% %         for iii = 1:4126 % 3574[1,3] 4120[1,3] 4126[1,3] 4132[1,3]
% %             if(unique(Y{iii}) > 1 & unique(Y{iii}) < 15)
% %                 aaa = [aaa,iii];
% %             end
% %         end
%         
%         labels_Y = Y{nodeIndex};
%         features_X = XX{nodeIndex};
%         figure1 = drawtsne(features_X, labels_Y, str_data_name{i});
%         
%         fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_tsne_all', int2str(nodeIndex)];
%         saveas(figure1, strcat([filePath, fileName_result], '.jpg'));
%         close All;
%         
%         %2 ��Լ����ͼ
%     %     labels_Y = data_array(:,end);
%         features_X_reduce = XX{nodeIndex}(:,vReducedFeaturesB_Reduce_End');
%         figure2 = drawtsne(features_X_reduce, labels_Y, str_data_name{i});
%         
%         fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_tsne_reduce', int2str(nodeIndex)];
%         saveas(figure2, strcat([filePath, fileName_result], '.jpg'));
%         close All;
%     end
% end

%% MFSIPMain.m+fs+acc(+tsne)Tree ok
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_MFSIP_Bridges.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.05, 0.2];
% for i = 9:9%length(str_test_name)
%     selectNode = [1,2,3,4,5];
%     for ii= 1:length(selectNode)
%         endlen = selectNode(ii); % 3-9 4-5 6-5 7-7
%     %     if(i == 5)
%     %         continue;
%     %     end
%         %0 load ���Լ�+����
% %         data_test_name = str_test_name{i};
% %         load (data_test_name);
% 
%         data_train_name = str_train_name{i};
%         load (data_train_name);
%         
%         data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
%         mat_name = str_mat_name{i};
%         load (mat_name);
%         
%         vReducedFeaturesB_End = vReducedFeaturesB{end-endlen};
%         vReducedFeaturesB_End_len = length(vReducedFeaturesB_End);
%         vFeatureNumRate = selectNum(i);
%         vFeatureNum = round(vReducedFeaturesB_End_len * vFeatureNumRate);
%         vReducedFeaturesB_Reduce_End = vReducedFeaturesB_End(1:vFeatureNum);
%         
%         %1 ��������ͼ
%     %     labels_Y = data_array(:,end);
%         [XX, Y] = creatSubTablezhIP(data_array, tree);
%         labels_Y = Y{end-endlen};
%         features_X = XX{end-endlen};
% %         figure1 = drawtsne(features_X, labels_Y, str_data_name{i});
% %         
% %         fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_tsne_all', int2str(endlen)];
% %         saveas(figure1, strcat([filePath, fileName_result], '.jpg'));
% %         close All;
%         
%         %2 ��Լ����ͼ
%     %     labels_Y = data_array(:,end);
%         features_X_reduce = XX{end-endlen}(:,vReducedFeaturesB_Reduce_End');
%         figure2 = drawtsne(features_X_reduce, labels_Y, str_data_name{i});
%         
%         fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_tsne_reduce', int2str(endlen)];
%         saveas(figure2, strcat([filePath, fileName_result], '.jpg'));
%         close All;
%     end
% end

%% MFSIPMain.m+fs+acc(+tsne)Tree
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_MFSIP_Bridges.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 8:8%length(str_test_name)
%     selectNode = [1,3];
%     for ii= 1:length(selectNode)
%         endlen = selectNode(ii); % 3-9 4-5 6-5 7-7
%     %     if(i == 5)
%     %         continue;
%     %     end
%         %0 load ���Լ�+����
% %         data_test_name = str_test_name{i};
% %         load (data_test_name);
% 
%         data_train_name = str_train_name{i};
%         load (data_train_name);
%         
%         data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
%         mat_name = str_mat_name{i};
%         load (mat_name);
%         
%         vReducedFeaturesB_End_len = length(vReducedFeaturesB_End);
%         vFeatureNumRate = selectNum(i);
%         vFeatureNum = round(vReducedFeaturesB_End_len * vFeatureNumRate);
%         vReducedFeaturesB_Reduce_End = vReducedFeaturesB_End(1:vFeatureNum);
%         
%         %1 ��������ͼ
%     %     labels_Y = data_array(:,end);
%         [XX, Y] = creatSubTablezhIP(data_array, tree);
%         labels_Y = Y{end-endlen};
%         features_X = XX{end-endlen};
%         figure1 = drawtsne(features_X, labels_Y, str_data_name{i});
%         
%         fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_tsne_all', int2str(endlen)];
%         saveas(figure1, strcat([filePath, fileName_result], '.jpg'));
%         close All;
%         
%         %2 ��Լ����ͼ
%     %     labels_Y = data_array(:,end);
%         features_X_reduce = XX{end-endlen}(:,vReducedFeaturesB_Reduce_End');
%         figure2 = drawtsne(features_X_reduce, labels_Y, str_data_name{i});
%         
%         fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_tsne_reduce', int2str(endlen)];
%         saveas(figure2, strcat([filePath, fileName_result], '.jpg'));
%         close All;
%     end
% end

%% MFSIPMain.m+fs+acc(+tsne)Tree
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_MFSIP_Bridges.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.5, 0.2, 0.2, 0.2];
% for i = 7:7%length(str_test_name)
%     selectNode = [4,6,7];
%     for ii= 1:length(selectNode)
%         nodeIndex = selectNode(ii); % 3-9 4-5 6-5 7-7
%     %     if(i == 5)
%     %         continue;
%     %     end
%         %0 load ���Լ�+����
% %         data_test_name = str_test_name{i};
% %         load (data_test_name);
% 
%         data_train_name = str_train_name{i};
%         load (data_train_name);
%         
%         data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
%         mat_name = str_mat_name{i};
%         load (mat_name);
%         
%         vReducedFeaturesB_End = vReducedFeaturesB{end-nodeIndex};
%         vReducedFeaturesB_End_len = length(vReducedFeaturesB_End);
%         vFeatureNumRate = selectNum(i);
%         vFeatureNum = round(vReducedFeaturesB_End_len * vFeatureNumRate);
%         vReducedFeaturesB_Reduce_End = vReducedFeaturesB_End(1:vFeatureNum);
%         
%         %1 ��������ͼ
%     %     labels_Y = data_array(:,end);
%         [XX, Y] = creatSubTablezhIP(data_array, tree);
%         labels_Y = Y{end-nodeIndex};
%         features_X = XX{end-nodeIndex};
%         figure1 = drawtsne(features_X, labels_Y, str_data_name{i});
%         
%         fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_tsne_all', int2str(nodeIndex)];
%         saveas(figure1, strcat([filePath, fileName_result], '.jpg'));
%         close All;
%         
%         %2 ��Լ����ͼ
%     %     labels_Y = data_array(:,end);
%         features_X_reduce = XX{end-nodeIndex}(:,vReducedFeaturesB_Reduce_End');
%         figure2 = drawtsne(features_X_reduce, labels_Y, str_data_name{i});
%         
%         fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_tsne_reduce', int2str(nodeIndex)];
%         saveas(figure2, strcat([filePath, fileName_result], '.jpg'));
%         close All;
%     end
% end

function [figure1] = drawtsne(features_X, labels_Y, dataName)
    % ִ�� t-SNE ��ά
    % ����Ĳ������Ը������������е���
    X_reduced = tsne(features_X, 'Algorithm', 'exact', 'NumDimensions', 2, 'Perplexity', 30);

    % ��ȡΨһ���Ͷ�Ӧ������
    unique_labels = unique(labels_Y);
    num_labels = length(unique_labels);

    % ������ɫӳ��
    color_map = lines(num_labels);

    % ����ͼ�β�����ÿ���������ݵ�
    figure123 = figure();
    hold on;
    for i = 1:num_labels
        idx = labels_Y == unique_labels(i);
        scatter(X_reduced(idx, 1), X_reduced(idx, 2), 25, color_map(i, :), 'filled');
    end
    hold off;

    % ���ӱ���ͱ�ǩ
    FontSize = 24;
    title(dataName,'Fontname', 'Times New Roman','FontSize',FontSize);
    set(gca,'FontName','Times New Roman','FontSize',FontSize);
%     xlabel('t-SNE Dimension 1','Fontname', 'Times New Roman','FontSize',FontSize);
%     ylabel('t-SNE Dimension 2','Fontname', 'Times New Roman','FontSize',FontSize);
    
%     xlabel(str,'Fontname', 'Times New Roman','FontSize',FontSize);
%     ylabel([str_function_F,'(', str_classifier,')'],'Fontname', 'Times New Roman','FontSize',FontSize);

    % ����ͼ��
    hl = legend(cellstr(num2str(unique_labels)));
%     set(hl,'Orientation','horizon');
    set(hl, 'location', 'NorthEast', 'FontSize', FontSize, 'FontName', 'Times New Roman');   

    % ��ʾ������
    grid on;
    
    figure1 = figure123;
end

%% �������
%% MFSIPMain.m+fs+�������
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for alphaArr_i = 1:length(alphaArr)
%     for betaArr_i = 1:length(betaArr)
%         
%         for i = 1:length(str_train_name)
%             if(i == 2 || i == 4 || i == 6 || i == 10)
%                 continue;
%             end
% %             if(alphaArr_i == 3 && betaArr_i == 3)
% %                 continue;
% %             end
%             %0 load
%             mat_name = str_train_name{i};
%             load (mat_name);
% 
%             %1 algorithm
%             alpha = alphaArr(alphaArr_i);
%             beta = betaArr(betaArr_i);
%             [feature_select, time, objDraw] = MFSIPMain(data_array, tree, alpha, beta);
% 
%             vTime = time;
%             vSamples = size(data_array,1);
%             vReducedFeaturesB = feature_select;
%             vAlpha = alpha;
%             vBeta = beta;
%             vObj = objDraw;
% 
%             %2 save
%             fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB', 'vAlpha', 'vBeta', 'vObj');
%         end
%         
%     end
% end

%% MFSIPMain.m+fs+acc(+RF)+�������
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for alphaArr_i = 1:length(alphaArr)
%     for betaArr_i = 1:length(betaArr)
%         
%         selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
%         for i = 1:length(str_test_name)
%             if(i == 2 || i == 4 || i == 6 || i == 10)
%                 continue;
%             end
% %             if(alphaArr_i == 3 && betaArr_i == 3)
% %                 continue;
% %             end
%             %0 load
%             data_test_name = str_test_name{i};
%             load (data_test_name);
% 
%             data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
%             
%             mat_name = [str_function_name{1}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             load (mat_name);
% 
%             vTime = vTime; % vtime_Arr(selectNum(i));
%             vSamples = size(data_array,1);
%             vReducedFeaturesB = vReducedFeaturesB;
%             vFeatureNumRate = selectNum(i);
%             vAlpha = vAlpha;
%             vBeta = vBeta;
% 
%             %2 save
%             method1 = 'KNN';
%             [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%             vac_KNN = accuracyMean_KNN;
%             vF_1_KNN = FHMean_KNN;
%             vF_LCA_KNN = F_LCAMean_KNN;
%             vTIE_KNN = TIEmean_KNN;
%             vac_Std_KNN = accuracyStd_KNN;
%             vF_1_Std_KNN = FHStd_KNN;
%             vF_LCA_Std_KNN = F_LCAStd_KNN;
%             vTIE_Std_KNN = TIEStd_KNN;
% 
%             vFeatureNum = numSeleted;
% 
%             method2 = 'SVM';
%             [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%             vac_SVM = accuracyMean_SVM;
%             vF_1_SVM = FHMean_SVM;
%             vF_LCA_SVM = F_LCAMean_SVM;
%             vTIE_SVM = TIEmean_SVM;
%             vac_Std_SVM = accuracyStd_SVM;
%             vF_1_Std_SVM = FHStd_SVM;
%             vF_LCA_Std_SVM = F_LCAStd_SVM;
%             vTIE_Std_SVM = TIEStd_SVM;
% 
%             method3 = 'RF';
%             [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%             vac_RF = accuracyMean_RF;
%             vF_1_RF = FHMean_RF;
%             vF_LCA_RF = F_LCAMean_RF;
%             vTIE_RF = TIEmean_RF;
%             vac_Std_RF = accuracyStd_RF;
%             vF_1_Std_RF = FHStd_RF;
%             vF_LCA_Std_RF = F_LCAStd_RF;
%             vTIE_Std_RF = TIEStd_RF;
% 
%             fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate', 'vAlpha', 'vBeta');
%         end
%         
%     end
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ����+������ͼ
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [0.01, 0.1, 0, 1, 10, 100];
% betaArr = [0.01, 0.1, 0, 1, 10, 100];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% 
% for i = 1:length(str_train_name)
% %     if(i == 5)
% %         continue;
% %     end
%     
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = -1;
%     for alphaArr_i = 1:length(alphaArr)
%         mean_data_arr = -1;
%         for betaArr_i = 1:length(betaArr)
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             
%             %mean_data_F_1 = (mat_name_data.vF_1_KNN + mat_name_data.vF_1_SVM + mat_name_data.vF_1_RF) / length(str_classifier_arr);
%             mean_data_F_1 = (mat_name_data.vac_KNN + mat_name_data.vac_SVM + mat_name_data.vac_RF) / length(str_classifier_arr);
% %             mean_data_F_1 = mat_name_data.vF_1_KNN;
%             
%             %if(mean_data_F_1 == 0)
%                 %mean_data_F_1 = min(mean_data_arr);
%             %end
%             
%             if(mean_data_arr == -1)
%                 mean_data_arr = mean_data_F_1;
%             else
%                 mean_data_arr = [mean_data_arr, mean_data_F_1];
%             end
%         end
%         if(mean_data_arr_two == -1)
%             mean_data_arr_two = mean_data_arr;
%         else
%             mean_data_arr_two = [mean_data_arr_two; mean_data_arr];
%         end
%     end
%     
%     %1 ��ɫ���ݱ���
%     % blue = 0.5;
%     mycolor = [1,1,1;...
%         0.9,0.9,0.9;...
%         0.75,0.75,0.75;...
%         0.4,0.4,0.4;...
%         0,0,0];
% 
%     %2 ������� ������������ϵ������
%     X = mean_data_arr_two;
% 
%     %3 ��ʼ������ͼ
%     % �������б������֣������ҿ����滻���Լ���Ҫ�ı�����
%     label_name_X = alphaArr;
%     label_name_Y = betaArr;%fliplr(label_name_X);
%     xlabel_name = label_name_X;
%     ylabel_name = label_name_Y;
%     % ��ͼ����Ϊheatmap;��ʼ����
%     figure1 = heatmap(xlabel_name, ylabel_name, X, 'FontSize', 15,'FontName','Times New Roman');
%     figure1.GridVisible = 'off'; % ������
%     % ����������������ͼ�Ĵ����
% %     figure1.Title = str_data_name{i};
%     figure1.XLabel = '��';
%     figure1.YLabel = '��';
% 
%     %4 ����ͼ��ɫ?colormap����
%     colormap(gca, mycolor);
% 
%     %5 ����ͼ
%     fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_para'];
%     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ����+������ͼ+ȥ��0 Acc Avg
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 1:length(str_train_name)
%     if(i == 2 || i == 4 || i == 6 || i == 10)
%         continue;
%     end
%     
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = -1;
%     for alphaArr_i = 1:length(alphaArr)
%         mean_data_arr = -1;
%         for betaArr_i = 1:length(betaArr)
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             
%             %mean_data_F_1 = (mat_name_data.vF_1_KNN + mat_name_data.vF_1_SVM + mat_name_data.vF_1_RF) / length(str_classifier_arr);
%             %mean_data_F_1 = (mat_name_data.vF_LCA_KNN + mat_name_data.vF_LCA_SVM + mat_name_data.vF_LCA_RF) / length(str_classifier_arr);
%             mean_data_F_1 = (mat_name_data.vac_KNN + mat_name_data.vac_SVM + mat_name_data.vac_RF) / length(str_classifier_arr);
%             %mean_data_F_1 = mat_name_data.vF_1_KNN;
%             
%             if(mean_data_arr == -1)
%                 mean_data_arr = mean_data_F_1;
%             else
%                 mean_data_arr = [mean_data_arr, mean_data_F_1];
%             end
%         end
%         if(mean_data_arr_two == -1)
%             mean_data_arr_two = mean_data_arr;
%         else
%             mean_data_arr_two = [mean_data_arr_two; mean_data_arr];
%         end
%     end
%     
%     %1 ��ɫ���ݱ���
%     % blue = 0.5;
%     mycolor = [1,1,1;...
%         0.9,0.9,0.9;...
%         0.75,0.75,0.75;...
%         0.4,0.4,0.4;...
%         0,0,0];
% 
%     %2 ������� ������������ϵ������
%     X = mean_data_arr_two;
% 
%     %3 ��ʼ������ͼ
%     % �������б������֣������ҿ����滻���Լ���Ҫ�ı�����
%     label_name_X = alphaArr;
%     label_name_Y = betaArr;%fliplr(label_name_X);
%     xlabel_name = label_name_X;
%     ylabel_name = label_name_Y;
%     % ��ͼ����Ϊheatmap;��ʼ����
%     figure1 = heatmap(xlabel_name, ylabel_name, X, 'FontSize', 15,'FontName','Times New Roman');
%     figure1.GridVisible = 'off'; % ������
%     % ����������������ͼ�Ĵ����
% %     figure1.Title = str_data_name{i};
%     figure1.XLabel = '��';
%     figure1.YLabel = '��';
% 
%     %4 ����ͼ��ɫ?colormap����
%     colormap(gca, mycolor);
% 
%     %5 ����ͼ
%     fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_para'];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, int2str(i), '_', str_data_name{i},'_AccAvg'], '.jpg'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ����+������ͼ+ȥ��0 F_1+F_LCA KNN
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 1:9%length(str_train_name)
%     if(i == 2 ||i == 3 || i == 4 || i == 5 || i == 6 || i == 10)
%         continue;
%     end
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = -1;
%     for alphaArr_i = 1:length(alphaArr)
%         mean_data_arr = -1;
%         for betaArr_i = 1:length(betaArr)
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             
%             %mean_data_F_1 = (mat_name_data.vF_1_KNN + mat_name_data.vF_1_SVM + mat_name_data.vF_1_RF) / length(str_classifier_arr);
%             %mean_data_F_1 = (mat_name_data.vF_LCA_KNN + mat_name_data.vF_LCA_SVM + mat_name_data.vF_LCA_RF) / length(str_classifier_arr);
%             %mean_data_F_1 = (mat_name_data.vac_KNN + mat_name_data.vac_SVM + mat_name_data.vac_RF) / length(str_classifier_arr);
%             mean_data_F_1 = mat_name_data.vF_LCA_SVM;
%             
%             if(mean_data_arr == -1)
%                 mean_data_arr = mean_data_F_1;
%             else
%                 mean_data_arr = [mean_data_arr, mean_data_F_1];
%             end
%         end
%         if(mean_data_arr_two == -1)
%             mean_data_arr_two = mean_data_arr;
%         else
%             mean_data_arr_two = [mean_data_arr_two; mean_data_arr];
%         end
%     end
%     
%     %1 ��ɫ���ݱ���
%     % blue = 0.5;
%     mycolor = [255,255,255;...
%         191,221,243;...
%         164,208,238;...
%         130,194,232;...
%         28,183,229]./255;
% 
%     %2 ������� ������������ϵ������
%     X = mean_data_arr_two.*100;
% 
%     %3 ��ʼ������ͼ
%     % �������б������֣������ҿ����滻���Լ���Ҫ�ı�����
%     label_name_X = alphaArr;
%     label_name_Y = betaArr;%fliplr(label_name_X);
%     xlabel_name = label_name_X;
%     ylabel_name = label_name_Y;
%     % ��ͼ����Ϊheatmap;��ʼ����
%     figure1 = heatmap(xlabel_name, ylabel_name, X, 'FontSize', 24,'FontName','Times New Roman');
%     figure1.GridVisible = 'off'; % ������
%     % ����������������ͼ�Ĵ����
% %     figure1.Title = str_data_name{i};
%     figure1.XLabel = '��';
%     figure1.YLabel = '��';
% 
%     %4 ����ͼ��ɫ?colormap����
%     colormap(gca, mycolor);
% 
%     %5 ����ͼ
%     fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_para'];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, int2str(i), '_', str_data_name{i},'_F_LCA','_SVM'], '.png'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ����+������ͼ+����ʵ�� F_1 KNN ���Ų���
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% str_function_name_F = {'F_1','F_{LCA}'};
% str_classfication_name = {'_KNN','_SVM'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 1:length(str_train_name)
%     if(i == 2 || i == 4 || i == 6 || i == 10)
%         continue;
%     end
%     %Bridges (alphaArr_i == 3 && betaArr_i == 4)
%     %CLEF (alphaArr_i == 5 && betaArr_i == 1)
%     %News20g (alphaArr_i == 5 && betaArr_i == 1)
%     %ILSVRC65 (alphaArr_i == 5 && betaArr_i == 1)
%     %Sun (alphaArr_i == 5 && betaArr_i == 1)
%     %Cifar100 (alphaArr_i == 5 && betaArr_i == 1)
%     
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = [0,0,0];
%     for alphaArr_i = 1:length(alphaArr)
%         for betaArr_i = 1:length(betaArr)
%             if (alphaArr_i == 3 && betaArr_i == 3)
%                 continue;
%             end
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             mean_data_F_1_F_LCA = mat_name_data.vF_1_KNN;
%             
%             if (i == 1)
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 6)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 6)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             else
%                 if (alphaArr_i == 5 && betaArr_i == 1)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 5 && betaArr_i == 6)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 1)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             end
%             
%         end
%     end
%     
%     %1 ����ͼƬ
%     figure1 = figure();
%     bar_x = 1:length(mean_data_arr_two);
% 
%     data_bar_y = mean_data_arr_two;
%     bar_x_y = bar(bar_x,data_bar_y,0.5);
%     
%     str_name_X = {'MFSIP','MFSIP-��','MFSIP-��'};
%     set(gca, 'XTickLabel', str_name_X, 'FontSize', 20, 'FontName', 'Times New Roman');
% 
%     if(i == 2 || i == 3 || i == 4 || i == 7 || i == 8 || i == 9 || i == 10)
%         aaa = 100;
%     elseif (i == 6)
%         aaa = 1000;
%     else
%         aaa = 100;
%     end
%     max1 = aaa*max(data_bar_y);
%     min1 = aaa*min(data_bar_y);
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     [~, maxIndex] = max(mean_data_arr_two);
%     [~, minIndex] = min(mean_data_arr_two);
%     if(maxIndex == minIndex)
%         maxIndex = 1;
%         minIndex = 2;
%     end
%     
%     dataIndexArr = 1:length(mean_data_arr_two);
%     dataIndexArr(ismember(dataIndexArr, maxIndex)) = [];
%     dataIndexArr(ismember(dataIndexArr, minIndex)) = [];
% 
%     bar_x_y.FaceColor = 'flat';
%     bar_x_y.CData(minIndex, :) = [255, 255, 255]./255;
%     bar_x_y.CData(dataIndexArr, :) = [199 ,199, 199]/255;
%     bar_x_y.CData(maxIndex, :) = [0, 0, 0]./255;
% 
%     ylabel(['\fontname{Times New Roman}\fontsize{20}', str_function_name_F{2}]);
% 
%     %2 ����ͼ
%     fileName_result = [algorithmName, '_xiaorong_fig_', str_data_name{2}];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, '5_', int2str(i), '_', str_data_name{i}, str_function_name_F{2}, str_classfication_name{2}], '.jpg'));
%     close All;%close(figure1);
% end

%% ����ͼ alpha(0.1)+beta(0.1) + ������ṹ
%% MFSIPMain.m+����ͼ
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Car196.mat'};
% str_mat_name1 = {'fs_result_MFSIP_Bridges_alpha5_beta5.mat','fs_result_MFSIP_DD_alpha5_beta5.mat','fs_result_MFSIP_CLEF_alpha5_beta5.mat','fs_result_MFSIP_VOC_alpha5_beta5.mat','fs_result_MFSIP_News20g_alpha5_beta5.mat','fs_result_MFSIP_F194_alpha5_beta5.mat','fs_result_MFSIP_ILSVRC65_alpha5_beta5.mat','fs_result_MFSIP_Sun_alpha5_beta5.mat','fs_result_MFSIP_Cifar100_alpha5_beta5.mat','fs_result_MFSIP_Car196_alpha5_beta5.mat'};
% str_mat_name2 = {'fs_result_MFSIP_Bridges_alpha5_beta6.mat','fs_result_MFSIP_DD_alpha5_beta6.mat','fs_result_MFSIP_CLEF_alpha5_beta6.mat','fs_result_MFSIP_VOC_alpha5_beta6.mat','fs_result_MFSIP_News20g_alpha5_beta6.mat','fs_result_MFSIP_F194_alpha5_beta6.mat','fs_result_MFSIP_ILSVRC65_alpha5_beta6.mat','fs_result_MFSIP_Sun_alpha5_beta6.mat','fs_result_MFSIP_Cifar100_alpha5_beta6.mat','fs_result_MFSIP_Car196_alpha5_beta6.mat'};
% str_mat_name3 = {'fs_result_MFSIP_Bridges_alpha6_beta5.mat','fs_result_MFSIP_DD_alpha6_beta5.mat','fs_result_MFSIP_CLEF_alpha6_beta5.mat','fs_result_MFSIP_VOC_alpha6_beta5.mat','fs_result_MFSIP_News20g_alpha6_beta5.mat','fs_result_MFSIP_F194_alpha6_beta5.mat','fs_result_MFSIP_ILSVRC65_alpha6_beta5.mat','fs_result_MFSIP_Sun_alpha6_beta5.mat','fs_result_MFSIP_Cifar100_alpha6_beta5.mat','fs_result_MFSIP_Car196_alpha6_beta5.mat'};
% str_mat_name_cell = {str_mat_name1;str_mat_name2;str_mat_name3};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% str_alpha_beta = {' (\alpha=0.01,\beta=0.01)',' (\alpha=0.01,\beta=0)',' (\alpha=0,\beta=0.01)'};
% str_alpha_beta_name = {'_alpha=0.01_beta=0.01','_alpha=0.01_beta=0','_alpha=0_beta=0.01'};
% 
% % alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% % betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for k = 1:length(str_mat_name_cell)
%     str_mat_name = str_mat_name_cell{k};
%     for i = 7:9%length(str_mat_name)
%         if(i == 2 || i == 4 || i == 6 || i == 10)
%             continue;
%         end
%         %0 load
%         mat_name = str_mat_name{i};
%         load (mat_name);
% 
%         %1 algorithm
%         objDraw = vObj;
% 
%         %3 ������ͼ
%         fontsize = 24;
%         figure1 = figure('Color',[1 1 1]);
%         axes1 = axes('Parent',figure1,'FontSize',fontsize,'FontName','Times New Roman');
% 
%         plot(objDraw,'LineWidth',4,'Color',[0 0 0]);
%         if(i == 5)
%             xlim(axes1,[0.8 30]);
%         else
%             xlim(axes1,[0.8 10]);
%         end
%         %ylim(axes1,[16000,36000]);%Cifar
%         %set(gca,'yscale','log') 
%         set(gca,'FontName','Times New Roman','FontSize',fontsize);
%         xlabel(['Iteration number',str_alpha_beta{k}]);
%         ylabel('Objective function value');
% 
%         fileName_result = [int2str(7),'_',int2str(i),'_',algorithmName, '_fig_', str_data_name{i},str_alpha_beta_name{k}];
%         saveas(figure1, strcat([filePath, fileName_result], '.png')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%         close(figure1);
%     end
% end

%% �����㷨�Ƚ� 
%% �����㷨�Ƚ�+fs
%% MFSIPMain.m+fs+1HFSGKFS
% clc;
% clear All;
% A_1_0 = [446,445,444,79,443,425,433,427,441,430,260,437,442,185,110,426,434,237,249,248,183,207,352,438,256,417,421,428,186,353,313,193,440,436,411,279,349,105,390,333];
% B_1_0 = [446,445,444,79,443,425,433,427,441,430,260,437,442,185,426,110,434,237,249,248,183,438,207,352,256,417,421,428,186,353,440,436,411,193,313,349,105,279,390,192];
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSGKFS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/1HFSGKFS/';
% 
% for i = 1:length(str_train_name)
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm
%     format long g;
%     num_FeaSelec = size(data_array,2)-1;
%     threshold = 2*10^(-4);
%     delta = 0.1;
%     [m,z] = size(data_array);
%     n = z-1;
%     index = floor(1+(m-1)*rand(floor(1*m),1))'; 
%     [XX,YY] = creatSubTable_Train(data_array(index,:),tree);
%     a1 = unique(YY{end});
%     a2 = unique(YY{end-1});
%     tic;
%     [Fea_Sel_id] = fun_HFSGKFS_TREEtrain(XX,YY,tree,delta,num_FeaSelec,n,threshold);
%     reducedFeaturesB = Fea_Sel_id;
%     traintime = toc;
%     format short;
% 
%     vTime = traintime;
%     vSamples = size(data_array,1);
%     for ii = 1:length(reducedFeaturesB)
%         reducedFeaturesB{ii} = reducedFeaturesB{ii}';
%     end
%     vReducedFeaturesB = reducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+fs+2HiRRfam-FS(-news)
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HiRRfam-FS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/2HiRRfam-FS/';
% 
% for i = 7:length(str_train_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm lambda = 10, alpha = 1, beta = 1;
%     lambda = 10; % 10
%     alpha = 1; % 1
%     beta = 1; % 1
%     flag = 0;
%     [X,Y] = creatSubTablezh(data_array, tree);
%     tic;
%     [feature] = HiFSRR02(X, Y, tree, lambda, alpha, beta, flag);
%     traintime = toc;
%     reducedFeaturesB = feature;
% 
%     vTime = traintime;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = reducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+fs+3HFSLDL(-news)
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSLDL';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/3HFSLDL/';
% 
% for i = 1:length(str_train_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm
%     alpha = 0.1; % pearson
%     beta = 0.1; % pearson
%     lambda1 = 10; % Optimization objectives
%     lambda2 = 0.2;
%     lambda3 = 0.1;
%     flag = 0;
%     cor = corr(data_array(:,1:end-1)',data_array(:,1:end-1)','type','pearson');
%     [X,Y,~,cor] = create_SubTable(data_array, tree,cor);
%     [Yd] = create_hier_distribution(Y,tree,cor,alpha,beta);
%     [treecor] = get_treecor(tree);
%     [sibcor] = get_sibcor(cor,Y,tree);
%     tic;
%     [feature_slct,W] = HFSLDL(X, Yd, tree, lambda1, treecor, sibcor, lambda2, lambda3, flag); %Feature selection
%     traintime = toc;
%     reducedFeaturesB = feature_slct;
% 
%     vTime = traintime;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = reducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+fs+4HFSCN(liu-sci-2)(-news)
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSCN';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/4HFSCN/';
% 
% for i = 5:5%length(str_train_name)
% %     if(i == 5 || i == 2)
% %         continue;
% %     end
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm
%     tic;
%     ClassLabel = data_array(:,end);
%     [M,N] = size(data_array);
%     P_outlier = 0.10;    % outlier percentage
%     N_outlier = round( M * P_outlier);
%     rand('seed',1); 
%     Fea_outlier = 10 * rand(N_outlier, N-1);
%     Label_outlier = randi([min(ClassLabel), max(ClassLabel)],N_outlier,1);
%     data_array = [data_array;Fea_outlier,Label_outlier];
%     [X, Y] = creatSubTable(data_array, tree);
%     lamda = 10;
%     alpha = 10;
%     epsi = 0.1;
%     flag = 0;
%     [nOutliers, feature] = HFSCN(X, Y, tree, lamda, alpha, epsi, flag);
%     traintime = toc;
%     
%     vTime = traintime;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = feature;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+fs+5HFSDK(liu-sci-1)
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSDK';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/5HFSDK/';
% 
% for i = 5:5%length(str_train_name)
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm
%     tic;
%     para.p = 2; % 1 or 2, Capped Lp-norm
%     para.NITER = 40; % iter times��ǰ4������ȷ��epsilon
%     para.alpha = 10^1;
%     para.beta = 10^1;
%     para.flag = 0;
%     [X, Y] = creatSubTable(data_array, tree);
%     [~, idx, ~, ~] = fun_Hier_CapLpSVM_W21_Wch(X, Y, tree, para);
%     feature = idx;
%     traintime = toc;
%     
%     vTime = traintime;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = feature;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+fs+6HFSGR(tuo+zhao)(-news)
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSGR';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/6HFSGR/';
% 
% for i = 1:length(str_train_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm
%     alpha = 1;
%     beita = 1;
%     Level_num  = max(tree(:,2));
%     [~, m] = size(data_array);
%     numSelected = m - 1;
%     [X, Y] = creatSubTablezh(data_array, tree);
%     tic;
%     [noLeafNode, F] = SubtreeRelationMatrix_F(tree);
%     [feature] = HFSGR_fast(X, Y, numSelected, tree, alpha, beita, noLeafNode, F, 0);
%     reducedFeaturesB = feature;
%     traintime = toc;
% 
%     vTime = traintime;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = reducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+fs+7HFSCF(-news)
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSCF';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/7HFSCF/';
% 
% for i = 9:length(str_train_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm
%     lambda = 10;
%     alpha = 0.005;
%     beta = 1;
%     indx = [];
%     [X, Y] = mycreatSubTablezh(data_array, tree);
%     tic;
%     [feature, ~] = HFSFC(X, Y, tree, lambda, alpha, beta, 0, data_array, indx);
%     reducedFeaturesB = feature;
%     traintime = toc;
% 
%     vTime = traintime;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = reducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+fs+8HFSLE(-news)
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSLE';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/8HFSLE/';
% 
% for i = 1:length(str_train_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm
%     lambda = 10;
%     alpha = 0.1;
%     theta = 0.1;
%     beta = 0.1;
%     [X, Y, Z]=create_SubTable2(data_array, tree);
%     tic;
%     [feature, ~, ~] = HFSLE(X, Y, Z, tree, lambda, alpha, theta, beta, 0);
%     reducedFeaturesB = feature;
%     traintime = toc;
% 
%     vTime = traintime;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = reducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% �����㷨�Ƚ�+acc
%% MFSIPMain.m+�����㷨�Ƚ�+acc(+Ada)+1HFSGKFS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSGKFS_Bridges.mat','fs_result_HFSGKFS_DD.mat','fs_result_HFSGKFS_CLEF.mat','fs_result_HFSGKFS_VOC.mat','fs_result_HFSGKFS_News20g.mat','fs_result_HFSGKFS_F194.mat','fs_result_HFSGKFS_ILSVRC65.mat','fs_result_HFSGKFS_Sun.mat','fs_result_HFSGKFS_Cifar100.mat','fs_result_HFSGKFS_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSGKFS';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/1HFSGKFS/';
% filePath = 'D:\Matlab\MFSIPMain\result\1HFSGKFS\';
% 
% selectNum = [0.5, 0.114, 0.2, 0.2, 0.03539, 0.142, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method4 = 'Ada';
%     [accuracyMean_Ada, accuracyStd_Ada, ~, FHMean_Ada, FHStd_Ada, F_LCAMean_Ada, F_LCAStd_Ada, ~, TIEmean_Ada, TIEStd_Ada, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method4, selectNum(i));
%     vac_Ada = accuracyMean_Ada;
%     vF_1_Ada = FHMean_Ada;
%     vF_LCA_Ada = F_LCAMean_Ada;
%     vTIE_Ada = TIEmean_Ada;
%     vac_Std_Ada = accuracyStd_Ada;
%     vF_1_Std_Ada = FHStd_Ada;
%     vF_LCA_Std_Ada = F_LCAStd_Ada;
%     vTIE_Std_Ada = TIEStd_Ada;
%     
%     vFeatureNum = numSeleted;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_Ada'];
%     save([filePath, fileName], 'vac_Ada', 'vF_1_Ada', 'vF_LCA_Ada', 'vTIE_Ada','vac_Std_Ada', 'vF_1_Std_Ada', 'vF_LCA_Std_Ada', 'vTIE_Std_Ada', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end
% 
% %% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+2HiRRfam-FS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HiRRfam-FS_Bridges.mat','fs_result_HiRRfam-FS_DD.mat','fs_result_HiRRfam-FS_CLEF.mat','fs_result_HiRRfam-FS_VOC.mat','1.mat','fs_result_HiRRfam-FS_F194.mat','fs_result_HiRRfam-FS_ILSVRC65.mat','fs_result_HiRRfam-FS_Sun.mat','fs_result_HiRRfam-FS_Cifar100.mat','fs_result_HiRRfam-FS_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HiRRfam-FS';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/2HiRRfam-FS/';
% filePath = 'D:\Matlab\MFSIPMain\result\2HiRRfam-FS\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method4 = 'Ada';
%     [accuracyMean_Ada, accuracyStd_Ada, ~, FHMean_Ada, FHStd_Ada, F_LCAMean_Ada, F_LCAStd_Ada, ~, TIEmean_Ada, TIEStd_Ada, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method4, selectNum(i));
%     vac_Ada = accuracyMean_Ada;
%     vF_1_Ada = FHMean_Ada;
%     vF_LCA_Ada = F_LCAMean_Ada;
%     vTIE_Ada = TIEmean_Ada;
%     vac_Std_Ada = accuracyStd_Ada;
%     vF_1_Std_Ada = FHStd_Ada;
%     vF_LCA_Std_Ada = F_LCAStd_Ada;
%     vTIE_Std_Ada = TIEStd_Ada;
%     
%     vFeatureNum = numSeleted;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_Ada'];
%     save([filePath, fileName], 'vac_Ada', 'vF_1_Ada', 'vF_LCA_Ada', 'vTIE_Ada','vac_Std_Ada', 'vF_1_Std_Ada', 'vF_LCA_Std_Ada', 'vTIE_Std_Ada', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end
% 
% %% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+3HFSLDL
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSLDL_Bridges.mat','fs_result_HFSLDL_DD.mat','fs_result_HFSLDL_CLEF.mat','fs_result_HFSLDL_VOC.mat','1.mat','fs_result_HFSLDL_F194.mat','fs_result_HFSLDL_ILSVRC65.mat','fs_result_HFSLDL_Sun.mat','fs_result_HFSLDL_Cifar100.mat','fs_result_HFSLDL_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSLDL';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/3HFSLDL/';
% filePath = 'D:\Matlab\MFSIPMain\result\3HFSLDL\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method4 = 'Ada';
%     [accuracyMean_Ada, accuracyStd_Ada, ~, FHMean_Ada, FHStd_Ada, F_LCAMean_Ada, F_LCAStd_Ada, ~, TIEmean_Ada, TIEStd_Ada, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method4, selectNum(i));
%     vac_Ada = accuracyMean_Ada;
%     vF_1_Ada = FHMean_Ada;
%     vF_LCA_Ada = F_LCAMean_Ada;
%     vTIE_Ada = TIEmean_Ada;
%     vac_Std_Ada = accuracyStd_Ada;
%     vF_1_Std_Ada = FHStd_Ada;
%     vF_LCA_Std_Ada = F_LCAStd_Ada;
%     vTIE_Std_Ada = TIEStd_Ada;
%     
%     vFeatureNum = numSeleted;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_Ada'];
%     save([filePath, fileName], 'vac_Ada', 'vF_1_Ada', 'vF_LCA_Ada', 'vTIE_Ada','vac_Std_Ada', 'vF_1_Std_Ada', 'vF_LCA_Std_Ada', 'vTIE_Std_Ada', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end
% 
% %% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+4HFSCN
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSCN_Bridges.mat','fs_result_HFSCN_DD.mat','fs_result_HFSCN_CLEF.mat','fs_result_HFSCN_VOC.mat','1.mat','fs_result_HFSCN_F194.mat','fs_result_HFSCN_ILSVRC65.mat','fs_result_HFSCN_Sun.mat','fs_result_HFSCN_Cifar100.mat','fs_result_HFSCN_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSCN';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/4HFSCN/';
% filePath = 'D:\Matlab\MFSIPMain\result\4HFSCN\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method4 = 'Ada';
%     [accuracyMean_Ada, accuracyStd_Ada, ~, FHMean_Ada, FHStd_Ada, F_LCAMean_Ada, F_LCAStd_Ada, ~, TIEmean_Ada, TIEStd_Ada, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method4, selectNum(i));
%     vac_Ada = accuracyMean_Ada;
%     vF_1_Ada = FHMean_Ada;
%     vF_LCA_Ada = F_LCAMean_Ada;
%     vTIE_Ada = TIEmean_Ada;
%     vac_Std_Ada = accuracyStd_Ada;
%     vF_1_Std_Ada = FHStd_Ada;
%     vF_LCA_Std_Ada = F_LCAStd_Ada;
%     vTIE_Std_Ada = TIEStd_Ada;
%     
%     vFeatureNum = numSeleted;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_Ada'];
%     save([filePath, fileName], 'vac_Ada', 'vF_1_Ada', 'vF_LCA_Ada', 'vTIE_Ada','vac_Std_Ada', 'vF_1_Std_Ada', 'vF_LCA_Std_Ada', 'vTIE_Std_Ada', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end
% 
% %% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+5HFSDK
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSDK_Bridges.mat','fs_result_HFSDK_DD.mat','fs_result_HFSDK_CLEF.mat','fs_result_HFSDK_VOC.mat','fs_result_HFSDK_News20g.mat','fs_result_HFSDK_F194.mat','fs_result_HFSDK_ILSVRC65.mat','fs_result_HFSDK_Sun.mat','fs_result_HFSDK_Cifar100.mat','fs_result_HFSDK_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSDK';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/5HFSDK/';
% filePath = 'D:\Matlab\MFSIPMain\result\5HFSDK\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method4 = 'Ada';
%     [accuracyMean_Ada, accuracyStd_Ada, ~, FHMean_Ada, FHStd_Ada, F_LCAMean_Ada, F_LCAStd_Ada, ~, TIEmean_Ada, TIEStd_Ada, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method4, selectNum(i));
%     vac_Ada = accuracyMean_Ada;
%     vF_1_Ada = FHMean_Ada;
%     vF_LCA_Ada = F_LCAMean_Ada;
%     vTIE_Ada = TIEmean_Ada;
%     vac_Std_Ada = accuracyStd_Ada;
%     vF_1_Std_Ada = FHStd_Ada;
%     vF_LCA_Std_Ada = F_LCAStd_Ada;
%     vTIE_Std_Ada = TIEStd_Ada;
%     
%     vFeatureNum = numSeleted;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_Ada'];
%     save([filePath, fileName], 'vac_Ada', 'vF_1_Ada', 'vF_LCA_Ada', 'vTIE_Ada','vac_Std_Ada', 'vF_1_Std_Ada', 'vF_LCA_Std_Ada', 'vTIE_Std_Ada', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end
% 
% %% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+6HFSGR
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSGR_Bridges.mat','fs_result_HFSGR_DD.mat','fs_result_HFSGR_CLEF.mat','fs_result_HFSGR_VOC.mat','fs_result_HFSGR_News20g.mat','fs_result_HFSGR_F194.mat','fs_result_HFSGR_ILSVRC65.mat','fs_result_HFSGR_Sun.mat','fs_result_HFSGR_Cifar100.mat','fs_result_HFSGR_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSGR';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/6HFSGR/';
% filePath = 'D:\Matlab\MFSIPMain\result\6HFSGR\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method4 = 'Ada';
%     [accuracyMean_Ada, accuracyStd_Ada, ~, FHMean_Ada, FHStd_Ada, F_LCAMean_Ada, F_LCAStd_Ada, ~, TIEmean_Ada, TIEStd_Ada, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method4, selectNum(i));
%     vac_Ada = accuracyMean_Ada;
%     vF_1_Ada = FHMean_Ada;
%     vF_LCA_Ada = F_LCAMean_Ada;
%     vTIE_Ada = TIEmean_Ada;
%     vac_Std_Ada = accuracyStd_Ada;
%     vF_1_Std_Ada = FHStd_Ada;
%     vF_LCA_Std_Ada = F_LCAStd_Ada;
%     vTIE_Std_Ada = TIEStd_Ada;
%     
%     vFeatureNum = numSeleted;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_Ada'];
%     save([filePath, fileName], 'vac_Ada', 'vF_1_Ada', 'vF_LCA_Ada', 'vTIE_Ada','vac_Std_Ada', 'vF_1_Std_Ada', 'vF_LCA_Std_Ada', 'vTIE_Std_Ada', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end
% 
% %% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+7HFSCF
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSCF_Bridges.mat','fs_result_HFSCF_DD.mat','fs_result_HFSCF_CLEF.mat','fs_result_HFSCF_VOC.mat','fs_result_HFSCF_News20g.mat','fs_result_HFSCF_F194.mat','fs_result_HFSCF_ILSVRC65.mat','fs_result_HFSCF_Sun.mat','fs_result_HFSCF_Cifar100.mat','fs_result_HFSCF_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSCF';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/7HFSCF/';
% filePath = 'D:\Matlab\MFSIPMain\result\7HFSCF\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method4 = 'Ada';
%     [accuracyMean_Ada, accuracyStd_Ada, ~, FHMean_Ada, FHStd_Ada, F_LCAMean_Ada, F_LCAStd_Ada, ~, TIEmean_Ada, TIEStd_Ada, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method4, selectNum(i));
%     vac_Ada = accuracyMean_Ada;
%     vF_1_Ada = FHMean_Ada;
%     vF_LCA_Ada = F_LCAMean_Ada;
%     vTIE_Ada = TIEmean_Ada;
%     vac_Std_Ada = accuracyStd_Ada;
%     vF_1_Std_Ada = FHStd_Ada;
%     vF_LCA_Std_Ada = F_LCAStd_Ada;
%     vTIE_Std_Ada = TIEStd_Ada;
%     
%     vFeatureNum = numSeleted;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_Ada'];
%     save([filePath, fileName], 'vac_Ada', 'vF_1_Ada', 'vF_LCA_Ada', 'vTIE_Ada','vac_Std_Ada', 'vF_1_Std_Ada', 'vF_LCA_Std_Ada', 'vTIE_Std_Ada', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end
% 
% %% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+8HFSLE
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSLE_Bridges.mat','fs_result_HFSLE_DD.mat','fs_result_HFSLE_CLEF.mat','fs_result_HFSLE_VOC.mat','fs_result_HFSLE_News20g.mat','fs_result_HFSLE_F194.mat','fs_result_HFSLE_ILSVRC65.mat','fs_result_HFSLE_Sun.mat','fs_result_HFSLE_Cifar100.mat','fs_result_HFSLE_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSLE';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/8HFSLE/';
% filePath = 'D:\Matlab\MFSIPMain\result\8HFSLE\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method4 = 'Ada';
%     [accuracyMean_Ada, accuracyStd_Ada, ~, FHMean_Ada, FHStd_Ada, F_LCAMean_Ada, F_LCAStd_Ada, ~, TIEmean_Ada, TIEStd_Ada, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method4, selectNum(i));
%     vac_Ada = accuracyMean_Ada;
%     vF_1_Ada = FHMean_Ada;
%     vF_LCA_Ada = F_LCAMean_Ada;
%     vTIE_Ada = TIEmean_Ada;
%     vac_Std_Ada = accuracyStd_Ada;
%     vF_1_Std_Ada = FHStd_Ada;
%     vF_LCA_Std_Ada = F_LCAStd_Ada;
%     vTIE_Std_Ada = TIEStd_Ada;
%     
%     vFeatureNum = numSeleted;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_Ada'];
%     save([filePath, fileName], 'vac_Ada', 'vF_1_Ada', 'vF_LCA_Ada', 'vTIE_Ada','vac_Std_Ada', 'vF_1_Std_Ada', 'vF_LCA_Std_Ada', 'vTIE_Std_Ada', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% �����㷨�Ƚ�+acc
%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+1HFSGKFS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSGKFS_Bridges.mat','fs_result_HFSGKFS_DD.mat','fs_result_HFSGKFS_CLEF.mat','fs_result_HFSGKFS_VOC.mat','fs_result_HFSGKFS_News20g.mat','fs_result_HFSGKFS_F194.mat','fs_result_HFSGKFS_ILSVRC65.mat','fs_result_HFSGKFS_Sun.mat','fs_result_HFSGKFS_Cifar100.mat','fs_result_HFSGKFS_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSGKFS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/1HFSGKFS/';
% 
% selectNum = [0.5, 0.114, 0.2, 0.2, 0.03539, 0.142, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+2HiRRfam-FS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HiRRfam-FS_Bridges.mat','fs_result_HiRRfam-FS_DD.mat','fs_result_HiRRfam-FS_CLEF.mat','fs_result_HiRRfam-FS_VOC.mat','1.mat','fs_result_HiRRfam-FS_F194.mat','fs_result_HiRRfam-FS_ILSVRC65.mat','fs_result_HiRRfam-FS_Sun.mat','fs_result_HiRRfam-FS_Cifar100.mat','fs_result_HiRRfam-FS_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HiRRfam-FS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/2HiRRfam-FS/';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 8:length(str_mat_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+3HFSLDL
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSLDL_Bridges.mat','fs_result_HFSLDL_DD.mat','fs_result_HFSLDL_CLEF.mat','fs_result_HFSLDL_VOC.mat','1.mat','fs_result_HFSLDL_F194.mat','fs_result_HFSLDL_ILSVRC65.mat','fs_result_HFSLDL_Sun.mat','fs_result_HFSLDL_Cifar100.mat','fs_result_HFSLDL_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSLDL';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/3HFSLDL/';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 3:3%length(str_mat_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+4HFSCN
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSCN_Bridges.mat','fs_result_HFSCN_DD.mat','fs_result_HFSCN_CLEF.mat','fs_result_HFSCN_VOC.mat','1.mat','fs_result_HFSCN_F194.mat','fs_result_HFSCN_ILSVRC65.mat','fs_result_HFSCN_Sun.mat','fs_result_HFSCN_Cifar100.mat','fs_result_HFSCN_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSCN';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/4HFSCN/';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+5HFSDK
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSDK_Bridges.mat','fs_result_HFSDK_DD.mat','fs_result_HFSDK_CLEF.mat','fs_result_HFSDK_VOC.mat','fs_result_HFSDK_News20g.mat','fs_result_HFSDK_F194.mat','fs_result_HFSDK_ILSVRC65.mat','fs_result_HFSDK_Sun.mat','fs_result_HFSDK_Cifar100.mat','fs_result_HFSDK_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSDK';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/5HFSDK/';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+6HFSGR
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSGR_Bridges.mat','fs_result_HFSGR_DD.mat','fs_result_HFSGR_CLEF.mat','fs_result_HFSGR_VOC.mat','fs_result_HFSGR_News20g.mat','fs_result_HFSGR_F194.mat','fs_result_HFSGR_ILSVRC65.mat','fs_result_HFSGR_Sun.mat','fs_result_HFSGR_Cifar100.mat','fs_result_HFSGR_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSGR';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/6HFSGR/';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+7HFSCF
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSCF_Bridges.mat','fs_result_HFSCF_DD.mat','fs_result_HFSCF_CLEF.mat','fs_result_HFSCF_VOC.mat','fs_result_HFSCF_News20g.mat','fs_result_HFSCF_F194.mat','fs_result_HFSCF_ILSVRC65.mat','fs_result_HFSCF_Sun.mat','fs_result_HFSCF_Cifar100.mat','fs_result_HFSCF_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSCF';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/7HFSCF/';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+8HFSLE
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_HFSLE_Bridges.mat','fs_result_HFSLE_DD.mat','fs_result_HFSLE_CLEF.mat','fs_result_HFSLE_VOC.mat','fs_result_HFSLE_News20g.mat','fs_result_HFSLE_F194.mat','fs_result_HFSLE_ILSVRC65.mat','fs_result_HFSLE_Sun.mat','fs_result_HFSLE_Cifar100.mat','fs_result_HFSLE_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'HFSLE';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/8HFSLE/';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:length(str_mat_name)
%     if(i == 5 || i == 2)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, selectNum(i));
%     vac_KNN = accuracyMean_KNN;
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     vac_Std_KNN = accuracyStd_KNN;
%     vF_1_Std_KNN = FHStd_KNN;
%     vF_LCA_Std_KNN = F_LCAStd_KNN;
%     vTIE_Std_KNN = TIEStd_KNN;
%     
%     vFeatureNum = numSeleted;
% 
%     method2 = 'SVM';
%     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, selectNum(i));
%     vac_SVM = accuracyMean_SVM;
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     vac_Std_SVM = accuracyStd_SVM;
%     vF_1_Std_SVM = FHStd_SVM;
%     vF_LCA_Std_SVM = F_LCAStd_SVM;
%     vTIE_Std_SVM = TIEStd_SVM;
%     
%     method3 = 'RF';
%     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, selectNum(i));
%     vac_RF = accuracyMean_RF;
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     vac_Std_RF = accuracyStd_RF;
%     vF_1_Std_RF = FHStd_RF;
%     vF_LCA_Std_RF = F_LCAStd_RF;
%     vTIE_Std_RF = TIEStd_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% xlsд��
% clc;
% clear All;
% 
% %0 ת������
% % str_mat_name_cell = {'acc_result_HFSGKFS_Bridges.mat','acc_result_HiRRfam-FS_Bridges.mat','acc_result_HFSLDL_Bridges.mat','acc_result_HFSCN_Bridges.mat','acc_result_HFSDK_Bridges.mat','acc_result_HFSGR_Bridges.mat','Middleacc_result_MFSIP_Bridges.mat';...
% %     'acc_result_HFSGKFS_DD.mat','acc_result_HiRRfam-FS_DD.mat','acc_result_HFSLDL_DD.mat','acc_result_HFSCN_DD.mat','acc_result_HFSDK_DD.mat','acc_result_HFSGR_DD.mat','Middleacc_result_MFSIP_DD.mat';...
% %     'acc_result_HFSGKFS_CLEF.mat','acc_result_HiRRfam-FS_CLEF.mat','acc_result_HFSLDL_CLEF.mat','acc_result_HFSCN_CLEF.mat','acc_result_HFSDK_CLEF.mat','acc_result_HFSGR_CLEF.mat','Middleacc_result_MFSIP_CLEF.mat';...
% %     'acc_result_HFSGKFS_VOC.mat','acc_result_HiRRfam-FS_VOC.mat','acc_result_HFSLDL_VOC.mat','acc_result_HFSCN_VOC.mat','acc_result_HFSDK_VOC.mat','acc_result_HFSGR_VOC.mat','Middleacc_result_MFSIP_VOC.mat';...
% %     'acc_result_HFSGKFS_News20g.mat','acc_result_HiRRfam-FS_News20g.mat','acc_result_HFSLDL_News20g.mat','acc_result_HFSCN_News20g.mat','acc_result_HFSDK_News20g.mat','acc_result_HFSGR_News20g.mat','Middleacc_result_MFSIP_News20g.mat';...
% %     'acc_result_HFSGKFS_F194.mat','acc_result_HiRRfam-FS_F194.mat','acc_result_HFSLDL_F194.mat','acc_result_HFSCN_F194.mat','acc_result_HFSDK_F194.mat','acc_result_HFSGR_F194.mat','Middleacc_result_MFSIP_F194.mat';...
% %     'acc_result_HFSGKFS_ILSVRC65.mat','acc_result_HiRRfam-FS_ILSVRC65.mat','acc_result_HFSLDL_ILSVRC65.mat','acc_result_HFSCN_ILSVRC65.mat','acc_result_HFSDK_ILSVRC65.mat','acc_result_HFSGR_ILSVRC65.mat','Middleacc_result_MFSIP_ILSVRC65.mat';...
% %     'acc_result_HFSGKFS_Sun.mat','acc_result_HiRRfam-FS_Sun.mat','acc_result_HFSLDL_Sun.mat','acc_result_HFSCN_Sun.mat','acc_result_HFSDK_Sun.mat','acc_result_HFSGR_Sun.mat','Middleacc_result_MFSIP_Sun.mat';...
% %     'acc_result_HFSGKFS_Cifar100.mat','acc_result_HiRRfam-FS_Cifar100.mat','acc_result_HFSLDL_Cifar100.mat','acc_result_HFSCN_Cifar100.mat','acc_result_HFSDK_Cifar100.mat','acc_result_HFSGR_Cifar100.mat','Middleacc_result_MFSIP_Cifar100.mat'};
% 
% str_mat_name_cell = {'acc_result_HFSGKFS_Bridges.mat','acc_result_HiRRfam-FS_Bridges.mat','acc_result_HFSLDL_Bridges.mat','acc_result_HFSCN_Bridges.mat','acc_result_HFSDK_Bridges.mat','acc_result_HFSGR_Bridges.mat','acc_result_HFSLE_Bridges.mat','acc_result_MFSIP_Bridges.mat';...
%                      'acc_result_HFSGKFS_News20g.mat','acc_result_HiRRfam-FS_News20g.mat','acc_result_HFSLDL_News20g.mat','acc_result_HFSCN_News20g.mat','acc_result_HFSDK_News20g.mat','acc_result_HFSGR_News20g.mat','acc_result_HFSLE_News20g.mat','acc_result_MFSIP_News20g.mat';...
%                      'acc_result_HFSGKFS_ILSVRC65.mat','acc_result_HiRRfam-FS_ILSVRC65.mat','acc_result_HFSLDL_ILSVRC65.mat','acc_result_HFSCN_ILSVRC65.mat','acc_result_HFSDK_ILSVRC65.mat','acc_result_HFSGR_ILSVRC65.mat','acc_result_HFSLE_ILSVRC65.mat','acc_result_MFSIP_ILSVRC65.mat';...
%                      'acc_result_HFSGKFS_Sun.mat','acc_result_HiRRfam-FS_Sun.mat','acc_result_HFSLDL_Sun.mat','acc_result_HFSCN_Sun.mat','acc_result_HFSDK_Sun.mat','acc_result_HFSGR_Sun.mat','acc_result_HFSLE_Sun.mat','acc_result_MFSIP_Sun.mat';...
%                      'acc_result_HFSGKFS_Cifar100.mat','acc_result_HiRRfam-FS_Cifar100.mat','acc_result_HFSLDL_Cifar100.mat','acc_result_HFSCN_Cifar100.mat','acc_result_HFSDK_Cifar100.mat','acc_result_HFSGR_Cifar100.mat','acc_result_HFSLE_Cifar100.mat','acc_result_MFSIP_Cifar100.mat';...
%                      'acc_result_HFSGKFS_CLEF.mat','acc_result_HiRRfam-FS_CLEF.mat','acc_result_HFSLDL_CLEF.mat','acc_result_HFSCN_CLEF.mat','acc_result_HFSDK_CLEF.mat','acc_result_HFSGR_CLEF.mat','acc_result_HFSLE_CLEF.mat','acc_result_MFSIP_CLEF.mat'};
% str_classifier_arr = {'KNN','SVM','RF'};
% fileNameXls = {'MFSIP_reslut_acc','MFSIP_reslut_F_1','MFSIP_reslut_F_LCA','MFSIP_reslut_TIE'};
% 
% filePath = '/Users/lindashuai/Documents/MATLAB/';
% 
% [dataSetNumRow, algoNumColumn] = size(str_mat_name_cell);
% dataResultCell = cell(dataSetNumRow, algoNumColumn);
% for i = 1:dataSetNumRow
%     for j = 1:algoNumColumn
%         mat_name = str_mat_name_cell{i,j};
%         mat_name_data = load (mat_name);
%         
%         vac_KNN = mat_name_data.vac_KNN;
%         vF_1_KNN = mat_name_data.vF_1_KNN;
%         vF_LCA_KNN = mat_name_data.vF_LCA_KNN;
%         vTIE_KNN = mat_name_data.vTIE_KNN;
% 
%         vac_SVM = mat_name_data.vac_SVM;
%         vF_1_SVM = mat_name_data.vF_1_SVM;
%         vF_LCA_SVM = mat_name_data.vF_LCA_SVM;
%         vTIE_SVM = mat_name_data.vTIE_SVM;
% 
%         vac_RF = mat_name_data.vac_RF;
%         vF_1_RF = mat_name_data.vF_1_RF;
%         vF_LCA_RF = mat_name_data.vF_LCA_RF;
%         vTIE_RF = mat_name_data.vTIE_RF;
%         
%         str_classifier_arr_len = length(str_classifier_arr);
%         vac_mean = (vac_KNN+vac_SVM+vac_RF)/str_classifier_arr_len;
%         vF_1_mean = (vF_1_KNN+vF_1_SVM+vF_1_RF)/str_classifier_arr_len;
%         vF_LCA_mean = (vF_LCA_KNN+vF_LCA_SVM+vF_LCA_RF)/str_classifier_arr_len;
%         vTIE_mean = (vTIE_KNN+vTIE_SVM+vTIE_RF)/str_classifier_arr_len;
%         
%         dataArr = [vac_KNN,vac_SVM,vac_RF,vac_mean;...
%             vF_1_KNN,vF_1_SVM,vF_1_RF,vF_1_mean;...
%             vF_LCA_KNN,vF_LCA_SVM,vF_LCA_RF,vF_LCA_mean;...
%             vTIE_KNN,vTIE_SVM,vTIE_RF,vTIE_mean];
% %         dataArr = [vac_KNN,vF_1_KNN,vF_LCA_KNN,vTIE_KNN;...
% %             vac_SVM,vF_1_SVM,vF_LCA_RF,vTIE_SVM;...
% %             vac_RF,vF_1_RF,vF_LCA_RF,vTIE_RF;...
% %             vac_mean,vF_1_mean,vF_LCA_mean,vTIE_mean];
%         dataResultCell{i,j} = dataArr;
%     end
% end
% 
% %0-1 Ԥ��������
% dataHandleResultCell = cell(length(str_classifier_arr)+1, algoNumColumn);
% % str_data_name = {'Bridges','DD','CLEF','VOC'}; %,'News20g','Cifar100','ILSVRC65','Sun'
% for k = 1:algoNumColumn
%     for p = 1:dataSetNumRow
%         dataResultArr_k_p = dataResultCell{p,k};
%         [row, ~] = size(dataResultArr_k_p);
%         for r = 1:row
%             k_p = dataResultArr_k_p(r,:);
%             dataHandleResultCell{r,k} = [dataHandleResultCell{r,k}, k_p];
%         end
%     end
% end
% 
% %1 д������
% % for x = 1:data_row
% %     for y = 1:data_column
% %         dataHandled_x_y = dataHandled{x,y}';
% % 
% %         %1-0 ��ȡС������λ
% %         pointsNum = 4;
% %         dataBig = dataHandled_x_y*10^pointsNum;
% %         dataFloor = floor(dataBig);
% %         dataHandled_x_y = dataFloor*10^(-pointsNum);
% % 
% %         %1-1 ��xls
% %         beginIndexNum = 1+(x-1);
% %         beginIndex = 65+(y-1); %L
% %         
% %         beginIndexChar = char(beginIndex);
% % %         endIndexChar = char(endIndex);
% % 
% % %         indexBeginEnd = [beginIndexChar, num2str(beginIndexNum), ':', endIndex, num2str(endIndexNum)];
% %         indexBeginEnd = [beginIndexChar, num2str(beginIndexNum)];
% %         xlswrite([fileNameXls, '.csv'], dataHandled_x_y, 'Sheet1', indexBeginEnd);
% %     end
% % end
% 
% dataHandled = dataHandleResultCell;
% 
% %1-0 ��ȡС������λ
% % pointsNum = 4;
% % dataBig = dataHandled_x_y*10^pointsNum;
% % dataFloor = floor(dataBig);
% % dataHandled_x_y = dataFloor*10^(-pointsNum);
% 
% for l = 1:length(fileNameXls)
%     [~, column] = size(dataHandled);
%     
%     data_xls_l = cell(1,column);
%     for g = 1:column
%         dataHandledArr = dataHandled{l,g}';
%         data_xls_l{1,g} = dataHandledArr;
%     end
%     
%     %1-1 ��xls
%     beginIndexNum = 1;
%     beginIndex = 65; %L
% 
%     beginIndexChar = char(beginIndex);
%     endIndexChar = char(beginIndex+column);
% %     indexBeginEnd = [beginIndexChar, num2str(beginIndexNum), ':', endIndex, num2str(beginIndexNum)];
%     indexBeginEnd = [beginIndexChar, num2str(beginIndexNum)];
%     xlswrite([fileNameXls{l}, '.csv'], data_xls_l, 'Sheet1', indexBeginEnd);
% end

%% 1Friedman
% clc;
% clear;
% %0 k=8���㷨 N=8�����ݼ�
% %1 alpha=0.05, q_{alpha}=2.69.
% 
% %2 Friedman
% %Friedman test statistic
% %FF follows a Fisher distribution with (k-1) and (k-1)(N-1) , F(7,49)
% %F(7,49)=2.203;
% method = 'TIE'; % Acc_{H} %F_{LCA} %TIE
% % dataAcc = [0.6067 	0.6067 	0.6067 	0.5817 	0.6000 	0.5967 	0.5917 	0.6167 ;...
% %     0.8030 	0.8072 	0.8097 	0.7669 	0.7583 	0.7557 	0.8191 	0.8214 ;...
% %     0.5621 	0.5913 	0.5912 	0.5866 	0.5842 	0.5770 	0.5836 	0.5949 ;...
% %     0.5876 	0.6040 	0.6035 	0.5999 	0.6034 	0.5971 	0.6071 	0.6139 ];
% 
% % dataF1 = [0.8119 	0.8132 	0.8132 	0.7991 	0.8016 	0.8099 	0.8024 	0.8168  ;...
% %     0.9453 	0.9469 	0.9476 	0.9364 	0.9340 	0.9337 	0.9498 	0.9506  ;...
% %     0.8164 	0.8293 	0.8297 	0.8267 	0.8263 	0.8223 	0.8269 	0.8313 ;...
% %     0.7709 	0.7804 	0.7798 	0.7782 	0.7800 	0.7774 	0.7823 	0.7867 ];
% 
% 
% % dataFLCA = [0.7850 	0.7840 	0.7840 	0.7693 	0.7772 	0.7780 	0.7743 	0.7890  ;...
% %     0.8981 	0.9006 	0.9018 	0.8801 	0.8757 	0.8746 	0.9064 	0.9078  ;...
% %     0.7363 	0.7543 	0.7544 	0.7511 	0.7499 	0.7449 	0.7500 	0.7567  ;...
% %     0.7480 	0.7582 	0.7577 	0.7557 	0.7578 	0.7544 	0.7602 	0.7646  ];
% 
% 
% dataTIE = [0.0992 	0.1000 	0.1000 	0.1070 	0.1054 	0.1023 	0.1054 	0.1000  ;...
%     0.0438 	0.0425 	0.0419 	0.0509 	0.0528 	0.0530 	0.0402 	0.0395 ;...
%     0.1469 	0.1365 	0.1362 	0.1386 	0.1390 	0.1422 	0.1385 	0.1349 ;...
%     0.1374 	0.1318 	0.1321 	0.1331 	0.1320 	0.1335 	0.1306 	0.1280 ];
% 
% 
% data = dataTIE;
% 
% [FF, averank, rank_w] = Friedman_test(data, method);
% a = 0;
% %3 Bonferroni-Dunn
% %%% ֱ�ӵ�python����
% %the Bonferroni-Dunn test, �Ա��㷨k=6, a=0.1, q=2.326
% %k=8,q=2.450
% %k=10,q=2.539
% %k=10,a=0.05,q=2.773
% % q = 2.85; % ������q_��
% % CD = CD_value(data,q);

%% ͼ�ṹ
% 0MFSIP F1 KNN(ok) RF SVM
%Cellcycle 0.337447492628581 0.308331342273680 0.291660149290114
%Derisi    0.339132011527778 0.342067620202201 X0.274514859615639
%Eisen     0.381751536470932 X0.369296161412552 X0.340884481668539
%Gasch     0.366336952553972 0.359737649856428 X0.298244895822385

% 1LCCSHFS F1 KNN RF SVM
%Cellcycle 0.320397793306080 0.308380355724688 0.287456844966788
%Derisi    0.329064260106051 0.340183478453583 0.364969393362071
%Eisen     0.368856468635153 0.374734647642011 0.378537805696442
%Gasch     0.360752382286233 0.358450040599014 0.328068775275591

% 0MFSIP FLCA KNN(ok) RF SVM
%Cellcycle 0.191138639063668 0.165388877541944 0.149809915842027
%Derisi    0.179464017020493 0.183242422806389 0.130578306207540
%Eisen     0.223569466391782 0.214630340801062 0.189557705948083
%Gasch     0.207462466323995 0.201748268334910 0.150858918650471

% 1LCCSHFS FLCA KNN RF SVM
%Cellcycle 0.177816252801358 0.166078298167914 0.149358827279023
%Derisi    0.171171272857032 0.182897953609937 0.203022686665407
%Eisen     0.211853126611998 0.217920740272828 0.218336125335071
%Gasch     0.205530002140304 0.202064117386065 0.169109619287481

% 0MFSIP TIE KNN(ok) RF SVM
%Cellcycle 1.117817896389325 1.324960753532182 1.423155416012559
%Derisi    1.177211155378486 1.180717131474104 1.657051792828685
%Eisen     1.078170731707317 1.204146341463415 1.364878048780488
%Gasch     1.097647058823529 1.161176470588235 1.503607843137255

% 1LCCSHFS TIE KNN RF SVM
%Cellcycle 1.197959183673469 1.309890109890110 1.428649921507064
%Derisi    1.187490039840637 1.190517928286853 0.952669322709163
%Eisen     1.118902439024390 1.206829268292683 1.147317073170732
%Gasch     1.107058823529412 1.165098039215686 1.279372549019608

% 2DFS
% 3Fisher
% 4WOAFS
% 5SCAFS
%% MFSIPMain.m+fs+ͼ�ṹ
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP_DAG';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 11:length(str_train_name)
%     %0 load
%     mat_name = str_train_name{i};
%     load (mat_name);
%     
%     %1 algorithm
%     alpha = 0.1;
%     beta = 0.1;
%     [feature_select, time, objDraw] = MFSIPDAGMain(data_array, DAG, alpha, beta);
% 
%     vTime = time;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = feature_select;
%     vAlpha = alpha;
%     vBeta = beta;
%     vObj = objDraw;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB', 'vAlpha', 'vBeta', 'vObj');
% end

%% MFSIPMain.m+ͼ�ṹ+acc(+RF)+10%-50%
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_MFSIP_DAG_Bridges.mat','fs_result_MFSIP_DAG_DD.mat','fs_result_MFSIP_DAG_CLEF.mat','fs_result_MFSIP_DAG_VOC.mat','fs_result_MFSIP_DAG_News20g.mat','fs_result_MFSIP_DAG_F194.mat','fs_result_MFSIP_DAG_ILSVRC65.mat','fs_result_MFSIP_DAG_Sun.mat','fs_result_MFSIP_DAG_Cifar100.mat','fs_result_MFSIP_DAG_Car196.mat','fs_result_MFSIP_DAG_Eisen.mat','fs_result_MFSIP_DAG_Derisi.mat','fs_result_MFSIP_DAG_Cellcycle.mat','fs_result_MFSIP_DAG_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'MFSIP_DAG';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% selectNumArr = [0.1, 0.2, 0.3, 0.4, 0.5];
% 
% for i = 11:11%length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime;
%     vSamples = size(data_array, 1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     
%     %1 save
%     for ii = 2:2%length(selectNumArr)
%         vFeatureNumRate = selectNumArr(ii);
% 
%         %2 save
%         method1 = 'KNN';
%         [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, numSeleted, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, selectNumArr(ii));
%         vF_1_KNN = FHMean_KNN;
%         vF_LCA_KNN = F_LCAMean_KNN;
%         vTIE_KNN = TIEmean_KNN;
% 
%         vFeatureNum = numSeleted;
% 
%         method2 = 'SVM';
%         [~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, vFeatureNum, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, selectNumArr(ii));
%         vF_1_SVM = FHMean_SVM;
%         vF_LCA_SVM = F_LCAMean_SVM;
%         vTIE_SVM = TIEmean_SVM;
% 
%         method3 = 'RF';
%         [~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, selectNumArr(ii));
%         vF_1_RF = FHMean_RF;
%         vF_LCA_RF = F_LCAMean_RF;
%         vTIE_RF = TIEmean_RF;
% 
%         fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, int2str(ii)];
%         save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
%     end
% end

%% ������� ͼ�ṹ
%% MFSIPMain.m+fs+������� ͼ�ṹ
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP1\';
% 
% for alphaArr_i = 1:length(alphaArr)
%     for betaArr_i = 1:length(betaArr)
%         
%         for i = 11:length(str_train_name)
% %             if(alphaArr_i == 3 && betaArr_i == 3)
% %                 continue;
% %             end
%             %0 load
%             mat_name = str_train_name{i};
%             load (mat_name);
% 
%             %1 algorithm
%             alpha = alphaArr(alphaArr_i);
%             beta = betaArr(betaArr_i);
%             [feature_select, time, objDraw] = MFSIPDAGMain(data_array, DAG, alpha, beta);
% 
%             vTime = time;
%             vSamples = size(data_array,1);
%             vReducedFeaturesB = feature_select;
%             vAlpha = alpha;
%             vBeta = beta;
%             vObj = objDraw;
% 
%             %2 save
%             fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB', 'vAlpha', 'vBeta', 'vObj');
%         end
%         
%     end
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ͼ�ṹ
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Car196.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP1\';
% 
% for alphaArr_i = 1:length(alphaArr)
%     for betaArr_i = 1:length(betaArr)
%         
%         selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
%         for i = 11:length(str_test_name)
% %             if(alphaArr_i == 3 && betaArr_i == 3)
% %                 continue;
% %             end
%             %0 load
%             data_test_name = str_test_name{i};
%             load (data_test_name);
% 
%             data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
%             
%             mat_name = [str_function_name{1}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             load (mat_name);
% 
%             vTime = vTime; % vtime_Arr(selectNum(i));
%             vSamples = size(data_array,1);
%             vReducedFeaturesB = vReducedFeaturesB;
%             vFeatureNumRate = selectNum(i);
%             vAlpha = vAlpha;
%             vBeta = vBeta;
% 
%             %2 save
%             method1 = 'KNN';
%             [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, numSeleted, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, vFeatureNumRate);
%             vF_1_KNN = FHMean_KNN;
%             vF_LCA_KNN = F_LCAMean_KNN;
%             vTIE_KNN = TIEmean_KNN;
% 
%             vFeatureNum = numSeleted;
% 
%             method2 = 'SVM';
%             [~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, vFeatureNum, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, vFeatureNumRate);
%             vF_1_SVM = FHMean_SVM;
%             vF_LCA_SVM = F_LCAMean_SVM;
%             vTIE_SVM = TIEmean_SVM;
% 
%             method3 = 'RF';
%             [~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, vFeatureNumRate);
%             vF_1_RF = FHMean_RF;
%             vF_LCA_RF = F_LCAMean_RF;
%             vTIE_RF = TIEmean_RF;
%             
%             fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate', 'vAlpha', 'vBeta');
%         end
%     end
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ͼ�ṹ ����+������ͼ+ȥ��0 F_LCA SVM
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 11:length(str_train_name)
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = -1;
%     for alphaArr_i = 1:length(alphaArr)
%         mean_data_arr = -1;
%         for betaArr_i = 1:length(betaArr)
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             
%             %mean_data_F_1 = (mat_name_data.vF_1_KNN + mat_name_data.vF_1_SVM + mat_name_data.vF_1_RF) / length(str_classifier_arr);
%             %mean_data_F_1 = (mat_name_data.vF_LCA_KNN + mat_name_data.vF_LCA_SVM + mat_name_data.vF_LCA_RF) / length(str_classifier_arr);
%             %mean_data_F_1 = (mat_name_data.vac_KNN + mat_name_data.vac_SVM + mat_name_data.vac_RF) / length(str_classifier_arr);
%             mean_data_F_1 = mat_name_data.vF_LCA_SVM;
%             
%             if(mean_data_arr == -1)
%                 mean_data_arr = mean_data_F_1;
%             else
%                 mean_data_arr = [mean_data_arr, mean_data_F_1];
%             end
%         end
%         if(mean_data_arr_two == -1)
%             mean_data_arr_two = mean_data_arr;
%         else
%             mean_data_arr_two = [mean_data_arr_two; mean_data_arr];
%         end
%     end
%     
%     %1 ��ɫ���ݱ���
%     % blue = 0.5;
% %     mycolor = [1,1,1;...
% %         0.9,0.9,0.9;...
% %         0.75,0.75,0.75;...
% %         0.4,0.4,0.4;...
% %         0,0,0];
%     mycolor = [255,255,255;...
%         191,221,243;...
%         164,208,238;...
%         130,194,232;...
%         28,183,229]./255;
% 
%     %2 ������� ������������ϵ������
%     X = mean_data_arr_two.*100;
% 
%     %3 ��ʼ������ͼ
%     % �������б������֣������ҿ����滻���Լ���Ҫ�ı�����
%     label_name_X = alphaArr;
%     label_name_Y = betaArr;%fliplr(label_name_X);
%     xlabel_name = label_name_X;
%     ylabel_name = label_name_Y;
%     % ��ͼ����Ϊheatmap;��ʼ����
%     figure1 = heatmap(xlabel_name, ylabel_name, X, 'FontSize', 24,'FontName','Times New Roman');
%     figure1.GridVisible = 'off'; % ������
%     % ����������������ͼ�Ĵ����
% %     figure1.Title = str_data_name{i};
%     figure1.XLabel = '��';
%     figure1.YLabel = '��';
% 
%     %4 ����ͼ��ɫ?colormap����
%     colormap(gca, mycolor);
% 
%     %5 ����ͼ
%     fileName_result = [algorithmName, '_fig_', str_data_name{i}, '_para'];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, int2str(i), '_', str_data_name{i},'_F_LCA','_SVM'], '.png'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ͼ�ṹ ����+������ͼ+����ʵ�� F_{1} KNN ���Ų���
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% str_function_name_F = {'F_1','F_{LCA}'};
% str_classfication_name = {'_KNN','_SVM'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 11:length(str_train_name)
%     %Bridges (alphaArr_i == 4 && betaArr_i == 4)
%     %News20g (alphaArr_i == 1 && betaArr_i == 1)
%     %ILSVRC65 (alphaArr_i == 1 && betaArr_i == 6)
%     %Sun (alphaArr_i == 1 && betaArr_i == 6)
%     %Cifar100 (alphaArr_i == 1 && betaArr_i ==6)
%     %Car196 (alphaArr_i == 1 && betaArr_i == 6)
%     
%     %Eisen (alphaArr_i == 2 && betaArr_i == 2)
%     %Derisi (alphaArr_i == 2 && betaArr_i == 2)
%     %Cellcycle (alphaArr_i == 2 && betaArr_i == 2)
%     %Gasch (alphaArr_i == 5 && betaArr_i == 5)
%     
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = [0,0,0];
%     for alphaArr_i = 1:length(alphaArr)
%         for betaArr_i = 1:length(betaArr)
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             mean_data_F_1_F_LCA = mat_name_data.vF_1_KNN;
%             
%             if (i == 11 || i == 12 || i == 13)
%                 if (alphaArr_i == 2 && betaArr_i == 2)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 2 && betaArr_i == 6)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 2)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             else
%                 if (alphaArr_i == 5 && betaArr_i == 5)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 5 && betaArr_i == 6)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 5)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             end
%             
%         end
%     end
%     
%     %1 ����ͼƬ
%     figure1 = figure();
%     bar_x = 1:length(mean_data_arr_two);
% 
%     data_bar_y = mean_data_arr_two;
%     bar_x_y = bar(bar_x,data_bar_y,0.5);
%     
%     str_name_X = {'MFSIP','MFSIP-��','MFSIP-��'};
%     set(gca, 'XTickLabel', str_name_X, 'FontSize', 20, 'FontName', 'Times New Roman');
% 
%     if(i == 2 || i == 3 || i == 4 || i == 7 || i == 8)
%         aaa = 100;
%     elseif (i == 6)
%         aaa = 1000;
%     else
%         aaa = 10;
%     end
%     max1 = aaa*max(data_bar_y);
%     min1 = aaa*min(data_bar_y);
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     [~, maxIndex] = max(mean_data_arr_two);
%     [~, minIndex] = min(mean_data_arr_two);
%     if(maxIndex == minIndex)
%         maxIndex = 1;
%         minIndex = 2;
%     end
%     
%     dataIndexArr = 1:length(mean_data_arr_two);
%     dataIndexArr(ismember(dataIndexArr, maxIndex)) = [];
%     dataIndexArr(ismember(dataIndexArr, minIndex)) = [];
% 
%     bar_x_y.FaceColor = 'flat';
%     bar_x_y.CData(minIndex, :) = [255, 255, 255]./255;
%     bar_x_y.CData(dataIndexArr, :) = [199 ,199, 199]/255;
%     bar_x_y.CData(maxIndex, :) = [0, 0, 0]./255;
% 
%     ylabel(['\fontname{Times New Roman}\fontsize{20}', str_function_name_F{1}]);
% 
%     %2 ����ͼ
%     fileName_result = [algorithmName, '_xiaorong_fig_', str_data_name{2}];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, '5_', int2str(i), '_', str_data_name{i}, str_function_name_F{2}, str_classfication_name{2}], '.jpg'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ͼ�ṹ ����+������ͼ+����ʵ�� F_{1} SVM ���Ų���
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% str_function_name_F = {'F_1','F_{LCA}'};
% str_classfication_name = {'_KNN','_SVM'};
% alphaArr = [0.01, 0.1, 0, 1, 10, 100];
% betaArr = [0.01, 0.1, 0, 1, 10, 100];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 11:length(str_train_name)
%     %Bridges (alphaArr_i == 4 && betaArr_i == 4)
%     %News20g (alphaArr_i == 1 && betaArr_i == 1)
%     %ILSVRC65 (alphaArr_i == 1 && betaArr_i == 6)
%     %Sun (alphaArr_i == 1 && betaArr_i == 6)
%     %Cifar100 (alphaArr_i == 1 && betaArr_i ==6)
%     %Car196 (alphaArr_i == 1 && betaArr_i == 6)
%     
%     %Eisen (alphaArr_i == 6 && betaArr_i == 4)
%     %Derisi (alphaArr_i == 2 && betaArr_i == 4)
%     %Cellcycle (alphaArr_i == 4 && betaArr_i == 4)
%     %Gasch (alphaArr_i == 6 && betaArr_i == 1)
%     
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = [0,0,0];
%     for alphaArr_i = 1:length(alphaArr)
%         for betaArr_i = 1:length(betaArr)
%             if (alphaArr_i == 3 && betaArr_i == 3)
%                 continue;
%             end
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             mean_data_F_1_F_LCA = mat_name_data.vF_1_SVM;
%             
%             if (i == 11)
%                 if (alphaArr_i == 6 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 12)
%                 if (alphaArr_i == 2 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 2 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 13)
%                 if (alphaArr_i == 4 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 4 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 14)
%                 if (alphaArr_i == 6 && betaArr_i == 1)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 1)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             else
%                 continue;
%             end
%             
%         end
%     end
%     
%     %1 ����ͼƬ
%     figure1 = figure();
%     bar_x = 1:length(mean_data_arr_two);
% 
%     data_bar_y = mean_data_arr_two;
%     bar_x_y = bar(bar_x,data_bar_y,0.5);
%     
%     str_name_X = {'MFSIP','MFSIP-��','MFSIP-��'};
%     set(gca, 'XTickLabel', str_name_X, 'FontSize', 20, 'FontName', 'Times New Roman');
% 
%     if(i == 2 || i == 3 || i == 4 || i == 7 || i == 8)
%         aaa = 100;
%     elseif (i == 6)
%         aaa = 1000;
%     else
%         aaa = 10;
%     end
%     max1 = aaa*max(data_bar_y);
%     min1 = aaa*min(data_bar_y);
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     [~, maxIndex] = max(mean_data_arr_two);
%     [~, minIndex] = min(mean_data_arr_two);
%     if(maxIndex == minIndex)
%         maxIndex = 1;
%         minIndex = 2;
%     end
%     
%     dataIndexArr = 1:length(mean_data_arr_two);
%     dataIndexArr(ismember(dataIndexArr, maxIndex)) = [];
%     dataIndexArr(ismember(dataIndexArr, minIndex)) = [];
% 
%     bar_x_y.FaceColor = 'flat';
%     bar_x_y.CData(minIndex, :) = [255, 255, 255]./255;
%     bar_x_y.CData(dataIndexArr, :) = [199 ,199, 199]/255;
%     bar_x_y.CData(maxIndex, :) = [0, 0, 0]./255;
% 
%     ylabel(['\fontname{Times New Roman}\fontsize{20}', str_function_name_F{1}]);
% 
%     %2 ����ͼ
%     fileName_result = [algorithmName, '_xiaorong_fig_', str_data_name{1}];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, '5_', int2str(i), '_', str_data_name{i}, str_function_name_F{1}, str_classfication_name{2}], '.jpg'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ͼ�ṹ ����+������ͼ+����ʵ�� F_{LCA} KNN ���Ų���
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% str_function_name_F = {'F_1','F_{LCA}'};
% str_classfication_name = {'_KNN','_SVM'};
% alphaArr = [0.01, 0.1, 0, 1, 10, 100];
% betaArr = [0.01, 0.1, 0, 1, 10, 100];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 11:length(str_train_name)
%     %Bridges (alphaArr_i == 4 && betaArr_i == 4)
%     %News20g (alphaArr_i == 1 && betaArr_i == 1)
%     %ILSVRC65 (alphaArr_i == 1 && betaArr_i == 6)
%     %Sun (alphaArr_i == 1 && betaArr_i == 6)
%     %Cifar100 (alphaArr_i == 1 && betaArr_i ==6)
%     %Car196 (alphaArr_i == 1 && betaArr_i == 6)
%     
%     %Eisen (alphaArr_i == 6 && betaArr_i == 4)
%     %Derisi (alphaArr_i == 2 && betaArr_i == 4)
%     %Cellcycle (alphaArr_i == 4 && betaArr_i == 4)
%     %Gasch (alphaArr_i == 6 && betaArr_i == 1)
%     
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = [0,0,0];
%     for alphaArr_i = 1:length(alphaArr)
%         for betaArr_i = 1:length(betaArr)
%             if (alphaArr_i == 3 && betaArr_i == 3)
%                 continue;
%             end
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             mean_data_F_1_F_LCA = mat_name_data.vF_LCA_KNN;
%             
%             if (i == 11)
%                 if (alphaArr_i == 6 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 12)
%                 if (alphaArr_i == 2 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 2 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 13)
%                 if (alphaArr_i == 4 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 4 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 14)
%                 if (alphaArr_i == 6 && betaArr_i == 1)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 1)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             else
%                 continue;
%             end
%             
%         end
%     end
%     
%     %1 ����ͼƬ
%     figure1 = figure();
%     bar_x = 1:length(mean_data_arr_two);
% 
%     data_bar_y = mean_data_arr_two;
%     bar_x_y = bar(bar_x,data_bar_y,0.5);
%     
%     str_name_X = {'MFSIP','MFSIP-��','MFSIP-��'};
%     set(gca, 'XTickLabel', str_name_X, 'FontSize', 20, 'FontName', 'Times New Roman');
% 
%     if(i == 2 || i == 3 || i == 4 || i == 7 || i == 8)
%         aaa = 100;
%     elseif (i == 6)
%         aaa = 1000;
%     else
%         aaa = 10;
%     end
%     max1 = aaa*max(data_bar_y);
%     min1 = aaa*min(data_bar_y);
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     [~, maxIndex] = max(mean_data_arr_two);
%     [~, minIndex] = min(mean_data_arr_two);
%     if(maxIndex == minIndex)
%         maxIndex = 1;
%         minIndex = 2;
%     end
%     
%     dataIndexArr = 1:length(mean_data_arr_two);
%     dataIndexArr(ismember(dataIndexArr, maxIndex)) = [];
%     dataIndexArr(ismember(dataIndexArr, minIndex)) = [];
% 
%     bar_x_y.FaceColor = 'flat';
%     bar_x_y.CData(minIndex, :) = [255, 255, 255]./255;
%     bar_x_y.CData(dataIndexArr, :) = [199 ,199, 199]/255;
%     bar_x_y.CData(maxIndex, :) = [0, 0, 0]./255;
% 
%     ylabel(['\fontname{Times New Roman}\fontsize{20}', str_function_name_F{2}]);
% 
%     %2 ����ͼ
%     fileName_result = [algorithmName, '_xiaorong_fig_', str_data_name{2}];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, '5_', int2str(i), '_', str_data_name{i}, str_function_name_F{2}, str_classfication_name{1}], '.jpg'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ����+������ͼ+����ʵ�� F_{LCA} SVM ���Ų���
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% str_function_name_F = {'F_1','F_{LCA}'};
% str_classfication_name = {'_KNN','_SVM'};
% alphaArr = [0.01, 0.1, 0, 1, 10, 100];
% betaArr = [0.01, 0.1, 0, 1, 10, 100];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 11:length(str_train_name)
%     %Bridges (alphaArr_i == 4 && betaArr_i == 4)
%     %News20g (alphaArr_i == 1 && betaArr_i == 1)
%     %ILSVRC65 (alphaArr_i == 1 && betaArr_i == 6)
%     %Sun (alphaArr_i == 1 && betaArr_i == 6)
%     %Cifar100 (alphaArr_i == 1 && betaArr_i ==6)
%     %Car196 (alphaArr_i == 1 && betaArr_i == 6)
%     
%     %Eisen (alphaArr_i == 6 && betaArr_i == 4)
%     %Derisi (alphaArr_i == 2 && betaArr_i == 4)
%     %Cellcycle (alphaArr_i == 4 && betaArr_i == 4)
%     %Gasch (alphaArr_i == 6 && betaArr_i == 1)
%     
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = [0,0,0];
%     for alphaArr_i = 1:length(alphaArr)
%         for betaArr_i = 1:length(betaArr)
%             if (alphaArr_i == 3 && betaArr_i == 3)
%                 continue;
%             end
%             mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%             mat_name_data = load (mat_name);
%             mean_data_F_1_F_LCA = mat_name_data.vF_LCA_SVM;
%             
%             if (i == 11)
%                 if (alphaArr_i == 6 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 12)
%                 if (alphaArr_i == 2 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 2 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 13)
%                 if (alphaArr_i == 4 && betaArr_i == 4)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 4 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 4)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             elseif (i == 14)
%                 if (alphaArr_i == 6 && betaArr_i == 1)
%                     mean_data_arr_two(1) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 6 && betaArr_i == 3)
%                     mean_data_arr_two(2) = mean_data_F_1_F_LCA;
%                 end
%                 if (alphaArr_i == 3 && betaArr_i == 1)
%                     mean_data_arr_two(3) = mean_data_F_1_F_LCA;
%                 end
%             else
%                 continue;
%             end
%             
%         end
%     end
%     
%     %1 ����ͼƬ
%     figure1 = figure();
%     bar_x = 1:length(mean_data_arr_two);
% 
%     data_bar_y = mean_data_arr_two;
%     bar_x_y = bar(bar_x,data_bar_y,0.5);
%     
%     str_name_X = {'MFSIP','MFSIP-��','MFSIP-��'};
%     set(gca, 'XTickLabel', str_name_X, 'FontSize', 20, 'FontName', 'Times New Roman');
% 
%     if(i == 2 || i == 3 || i == 4 || i == 7 || i == 8)
%         aaa = 100;
%     elseif (i == 6)
%         aaa = 1000;
%     else
%         aaa = 10;
%     end
%     max1 = aaa*max(data_bar_y);
%     min1 = aaa*min(data_bar_y);
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     [~, maxIndex] = max(mean_data_arr_two);
%     [~, minIndex] = min(mean_data_arr_two);
%     if(maxIndex == minIndex)
%         maxIndex = 1;
%         minIndex = 2;
%     end
%     
%     dataIndexArr = 1:length(mean_data_arr_two);
%     dataIndexArr(ismember(dataIndexArr, maxIndex)) = [];
%     dataIndexArr(ismember(dataIndexArr, minIndex)) = [];
% 
%     bar_x_y.FaceColor = 'flat';
%     bar_x_y.CData(minIndex, :) = [255, 255, 255]./255;
%     bar_x_y.CData(dataIndexArr, :) = [199 ,199, 199]/255;
%     bar_x_y.CData(maxIndex, :) = [0, 0, 0]./255;
% 
%     ylabel(['\fontname{Times New Roman}\fontsize{20}', str_function_name_F{2}]);
% 
%     %2 ����ͼ
%     fileName_result = [algorithmName, '_xiaorong_fig_', str_data_name{2}];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, '5_', int2str(i), '_', str_data_name{i}, str_function_name_F{2}, str_classfication_name{2}], '.jpg'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ͼ�ṹ ����+������ͼ+����ʵ�� F_{LCA} KNN
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [0.01, 0.1, 0, 1, 10, 100];
% betaArr = [0.01, 0.1, 0, 1, 10, 100];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 11:length(str_train_name)
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = [];
%     for alphaArr_i = 1:length(alphaArr)
%         mean_data_arr = [];
%         for betaArr_i = 1:length(betaArr)
%             
%             if ((alphaArr_i == 2 && betaArr_i == 2) || (alphaArr_i == 2 && betaArr_i == 3) || (alphaArr_i == 3 && betaArr_i == 2))
%                 mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%                 mat_name_data = load (mat_name);
% 
%                 %mean_data_F_1 = (mat_name_data.vF_1_KNN + mat_name_data.vF_1_SVM + mat_name_data.vF_1_RF) / length(str_classifier_arr);
%                 %mean_data_F_1 = (mat_name_data.vac_KNN + mat_name_data.vac_SVM + mat_name_data.vac_RF) / length(str_classifier_arr);
%                 mean_data_F_1 = mat_name_data.vF_LCA_KNN;
%             
%                 mean_data_arr = [mean_data_arr, mean_data_F_1];
%             end
%             
%         end
%         if (alphaArr_i == 2 || alphaArr_i == 3)
%             mean_data_arr_two = [mean_data_arr_two, mean_data_arr];
%         end
%     end
%     
%     %1 ����ͼƬ
%     figure1 = figure();
%     bar_x = 1:length(mean_data_arr_two);
% 
%     data_bar_y = mean_data_arr_two;
%     bar_x_y = bar(bar_x,data_bar_y,0.5);
%     
%     str_name_X = {'MFSIP','MFSIP-��','MFSIP-��'};
%     set(gca, 'XTickLabel', str_name_X, 'FontSize', 20, 'FontName', 'Times New Roman');
% 
%     if(i == 2 || i == 3 || i == 4 || i == 7 || i == 8)
%         aaa = 100;
%     elseif (i == 6)
%         aaa = 1000;
%     else
%         aaa = 10;
%     end
%     max1 = aaa*max(data_bar_y);
%     min1 = aaa*min(data_bar_y);
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     [~, maxIndex] = max(mean_data_arr_two);
%     [~, minIndex] = min(mean_data_arr_two);
%     if(maxIndex == minIndex)
%         maxIndex = 1;
%         minIndex = 2;
%     end
%     
%     dataIndexArr = 1:length(mean_data_arr_two);
%     dataIndexArr(ismember(dataIndexArr, maxIndex)) = [];
%     dataIndexArr(ismember(dataIndexArr, minIndex)) = [];
% 
%     bar_x_y.FaceColor = 'flat';
%     bar_x_y.CData(minIndex, :) = [255, 255, 255]./255;
%     bar_x_y.CData(dataIndexArr, :) = [199 ,199, 199]/255;
%     bar_x_y.CData(maxIndex, :) = [0, 0, 0]./255;
% 
%     ylabel(['\fontname{Times New Roman}\fontsize{20}', 'F_{LCA}']);
% 
%     %2 ����ͼ
%     fileName_result = [algorithmName, '_xiaorong_fig_', str_data_name{i}];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, '5_', int2str(i), '_', str_data_name{i},'_KNN'], '.jpg'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+������� ͼ�ṹ ����+������ͼ+����ʵ�� F_{LCA} SVM
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges_alpha1_beta1.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [0.01, 0.1, 0, 1, 10, 100];
% betaArr = [0.01, 0.1, 0, 1, 10, 100];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for i = 11:length(str_train_name)
%     %0 ׼������
%     str_classifier_arr = {'KNN','SVM','RF'};
%     mean_data_arr_two = [];
%     for alphaArr_i = 1:length(alphaArr)
%         mean_data_arr = [];
%         for betaArr_i = 1:length(betaArr)
%             
%             if ((alphaArr_i == 2 && betaArr_i == 2) || (alphaArr_i == 2 && betaArr_i == 3) || (alphaArr_i == 3 && betaArr_i == 2))
%                 mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%                 mat_name_data = load (mat_name);
% 
%                 %mean_data_F_1 = (mat_name_data.vF_1_KNN + mat_name_data.vF_1_SVM + mat_name_data.vF_1_RF) / length(str_classifier_arr);
%                 %mean_data_F_1 = (mat_name_data.vac_KNN + mat_name_data.vac_SVM + mat_name_data.vac_RF) / length(str_classifier_arr);
%                 mean_data_F_1 = mat_name_data.vF_LCA_SVM;
%             
%                 mean_data_arr = [mean_data_arr, mean_data_F_1];
%             end
%             
%         end
%         if (alphaArr_i == 2 || alphaArr_i == 3)
%             mean_data_arr_two = [mean_data_arr_two, mean_data_arr];
%         end
%     end
%     
%     %1 ����ͼƬ
%     figure1 = figure();
%     bar_x = 1:length(mean_data_arr_two);
% 
%     data_bar_y = mean_data_arr_two;
%     bar_x_y = bar(bar_x,data_bar_y,0.5);
%     
%     str_name_X = {'MFSIP','MFSIP-��','MFSIP-��'};
%     set(gca, 'XTickLabel', str_name_X, 'FontSize', 20, 'FontName', 'Times New Roman');
% 
%     if(i == 2 || i == 3 || i == 4 || i == 7 || i == 8)
%         aaa = 100;
%     elseif (i == 6)
%         aaa = 1000;
%     else
%         aaa = 10;
%     end
%     max1 = aaa*max(data_bar_y);
%     min1 = aaa*min(data_bar_y);
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     [~, maxIndex] = max(mean_data_arr_two);
%     [~, minIndex] = min(mean_data_arr_two);
%     if(maxIndex == minIndex)
%         maxIndex = 1;
%         minIndex = 2;
%     end
%     
%     dataIndexArr = 1:length(mean_data_arr_two);
%     dataIndexArr(ismember(dataIndexArr, maxIndex)) = [];
%     dataIndexArr(ismember(dataIndexArr, minIndex)) = [];
% 
%     bar_x_y.FaceColor = 'flat';
%     bar_x_y.CData(minIndex, :) = [255, 255, 255]./255;
%     bar_x_y.CData(dataIndexArr, :) = [199 ,199, 199]/255;
%     bar_x_y.CData(maxIndex, :) = [0, 0, 0]./255;
% 
%     ylabel(['\fontname{Times New Roman}\fontsize{20}', 'F_{LCA}']);
% 
%     %2 ����ͼ
%     fileName_result = [algorithmName, '_xiaorong_fig_', str_data_name{i}];
% %     saveas(figure1, strcat([filePath, fileName_result], '.jpg')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     saveas(figure1, strcat([filePath, '5_', int2str(i), '_', str_data_name{i},'_SVM'], '.jpg'));
%     close All;%close(figure1);
% end

%% MFSIPMain.m+����ͼ ͼ�ṹ
% clc;
% clear All;
% 
% % str_mat_name = {'fs_result_MFSIP_Bridges.mat','fs_result_MFSIP_DD.mat','fs_result_MFSIP_CLEF.mat','fs_result_MFSIP_VOC.mat','fs_result_MFSIP_News20g.mat','fs_result_MFSIP_F194.mat','fs_result_MFSIP_ILSVRC65.mat','fs_result_MFSIP_Sun.mat','fs_result_MFSIP_Cifar100.mat','fs_result_MFSIP_Eisen.mat','fs_result_MFSIP_Car196.mat','fs_result_MFSIP_Derisi.mat','fs_result_MFSIP_Cellcycle.mat','fs_result_MFSIP_Gasch.mat'};
% str_mat_name1 = {'fs_result_MFSIP_Bridges_alpha5_beta5.mat','fs_result_MFSIP_DD_alpha5_beta5.mat','fs_result_MFSIP_CLEF_alpha5_beta5.mat','fs_result_MFSIP_VOC_alpha5_beta5.mat','fs_result_MFSIP_News20g_alpha5_beta5.mat','fs_result_MFSIP_F194_alpha5_beta5.mat','fs_result_MFSIP_ILSVRC65_alpha5_beta5.mat','fs_result_MFSIP_Sun_alpha5_beta5.mat','fs_result_MFSIP_Cifar100_alpha5_beta5.mat','fs_result_MFSIP_Car196_alpha5_beta5.mat','fs_result_MFSIP_Eisen_alpha5_beta5.mat','fs_result_MFSIP_Derisi_alpha5_beta5.mat','fs_result_MFSIP_Cellcycle_alpha5_beta5.mat','fs_result_MFSIP_Gasch_alpha5_beta5.mat'};
% str_mat_name2 = {'fs_result_MFSIP_Bridges_alpha5_beta6.mat','fs_result_MFSIP_DD_alpha5_beta6.mat','fs_result_MFSIP_CLEF_alpha5_beta6.mat','fs_result_MFSIP_VOC_alpha5_beta6.mat','fs_result_MFSIP_News20g_alpha5_beta6.mat','fs_result_MFSIP_F194_alpha5_beta6.mat','fs_result_MFSIP_ILSVRC65_alpha5_beta6.mat','fs_result_MFSIP_Sun_alpha5_beta6.mat','fs_result_MFSIP_Cifar100_alpha5_beta6.mat','fs_result_MFSIP_Car196_alpha5_beta6.mat','fs_result_MFSIP_Eisen_alpha5_beta6.mat','fs_result_MFSIP_Derisi_alpha5_beta6.mat','fs_result_MFSIP_Cellcycle_alpha5_beta6.mat','fs_result_MFSIP_Gasch_alpha5_beta6.mat'};
% str_mat_name3 = {'fs_result_MFSIP_Bridges_alpha6_beta5.mat','fs_result_MFSIP_DD_alpha6_beta5.mat','fs_result_MFSIP_CLEF_alpha6_beta5.mat','fs_result_MFSIP_VOC_alpha6_beta5.mat','fs_result_MFSIP_News20g_alpha6_beta5.mat','fs_result_MFSIP_F194_alpha6_beta5.mat','fs_result_MFSIP_ILSVRC65_alpha6_beta5.mat','fs_result_MFSIP_Sun_alpha6_beta5.mat','fs_result_MFSIP_Cifar100_alpha6_beta5.mat','fs_result_MFSIP_Car196_alpha6_beta5.mat','fs_result_MFSIP_Eisen_alpha6_beta5.mat','fs_result_MFSIP_Derisi_alpha6_beta5.mat','fs_result_MFSIP_Cellcycle_alpha6_beta5.mat','fs_result_MFSIP_Gasch_alpha6_beta5.mat'};
% str_mat_name_cell = {str_mat_name1;str_mat_name2;str_mat_name3};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% str_alpha_beta = {' (\alpha=0.01,\beta=0.01)',' (\alpha=0.01,\beta=0)',' (\alpha=0,\beta=0.01)'};
% str_alpha_beta_name = {'_alpha=0.01_beta=0.01','_alpha=0.01_beta=0','_alpha=0_beta=0.01'};
% 
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% for k = 1:length(str_mat_name_cell)
%     str_mat_name = str_mat_name_cell{k};
%     for i = 11:length(str_mat_name)
%         %0 load
%         mat_name = str_mat_name{i};
%         load (mat_name);
% 
%         %1 algorithm
%         objDraw = vObj;
% 
%         %3 ������ͼ
%         fontsize = 24;
%         figure1 = figure('Color',[1 1 1]);
%         axes1 = axes('Parent',figure1,'FontSize',fontsize,'FontName','Times New Roman');
% 
%         plot(objDraw,'LineWidth',4,'Color',[0 0 0]);
%         if(i == 5)
%             xlim(axes1,[0.8 30]);
%         else
%             xlim(axes1,[0.8 10]);
%         end
%         %ylim(axes1,[16000,36000]);%Cifar
%         %set(gca,'yscale','log') 
%         set(gca,'FontName','Times New Roman','FontSize',fontsize);
%         xlabel(['Iteration number',str_alpha_beta{k}]);
%         ylabel('Objective function value');
% 
%         fileName_result = [int2str(7),'_',int2str(i),'_',algorithmName, '_fig_', str_data_name{i},str_alpha_beta_name{k}];
%         saveas(figure1, strcat([filePath, fileName_result], '.png')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%         close(figure1);
%     end
% end

%% ��ͼ��ά����ͼ
% clear;
% clc;
% 
% x = [-8:0.5:8];
% y = [-8:0.5:8];
% [X, Y] = meshgrid(x, y);
% Z = X.*X;
% 
% Z = (norm((X*Z - Y), 'fro'))^2 + sum(sqrt(sum((Z).*(Z),2)));
% % R = sqrt(X.^2 + Y.^2);
% % Z = sin(R)./R;
% mesh(X, Y, Z);
% % figure;
% surf(X, Y, Z);

% hold on
% colormap hsv

% plt.axes();
% ax = title('surfc');
% % xlabel('X');
% ylabel('Y');
% zlabel('Z'); 
% grid on;

% clear;
% clc;
% 
% plt = plot(1,1);
% % [~, ax] = plt.plot();
% [X,Y,Z]=peaks(30);
% waterfall(X,Y,Z)
% 
% % set(gca,'XColor', [1 1 1], 'YColor', [1 1 1])
% 
% % plt.gca().get_xaxis().set_visible(False)
% % plt.gca().get_yaxis().set_visible(False)
% 
% set(gca,'XColor', [1 1 1], 'YColor', [1 1 1])
% 
% % % ������������
% % hAxes = gca;
% % hAxes.XRuler.Axle.LineStyle = 'Null';
% % hAxes.YRuler.Axle.LineStyle = 'Null';
% 
% xlabel('X');
% ylabel('Y');
% zlabel('Z');
% 

% clear;
% clc;
% 
% x=0:0.1:1.5*pi;
% [x,y]=meshgrid(x);
% z=sin(y-3.5).*cos(x-1.1);
% mesh(x,y,z);
% % set(gca,'XColor', [1 1 1], 'YColor', [1 1 1]);
% set(gca,'FontName','Times New Roman','FontSize',16);
% xlabel('W_i');
% ylabel('D_i');
% 
% % zlabel('O(W_i,D_i)');
% title('O(W_i,D_i)');
% grid on;

%% �����㷨�Ƚ�+SL
%% �����㷨�Ƚ�+SL+fs
%% MFSIPMain.m+fs+1+11LCCSHFS
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'LCCSHFS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/11LCCSHFS/';
% % filePath = 'D:\Matlab\MFSIPMain\result\11LCCSHFS\';
% 
% for i = 11:11%length(str_train_name)
%     %0 load
%     train_name = str_train_name{i};
%     load (train_name);
%     
%     %1 algorithm
%     XYfilename = [train_name 'Train4XY.mat'];
%     if ~exist(XYfilename,'file')
%         [X,Y] = creatSubTablezh_DAG(data_array, DAG);
%         save([filePath, XYfilename], 'X', 'Y');
%     else
%         load (XYfilename);
%     end
%     %Feature selection
%     tic;
%     lambda = 100;
%     alpha = 0.001;
%     R  = pdist2(train_target'+eps, train_target'+eps, 'cosine');
%     [feature_slct, ~] = LCCSHFS(X, Y, DAG, lambda, alpha, 0, R);
%     vTime = toc;
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = feature_slct;
%     vFeatureNum = length(vReducedFeaturesB);
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum');
% end

%% MFSIPMain.m+IP+fs+12DFS
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'DFS';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/12DFS/';
% filePath = 'D:\Matlab\MFSIPMain\result\12DFS\';
% 
% for i = 11:length(str_train_name)
%     %0 load
%     mat_name = str_train_name{i};
%     load (mat_name);
%     
%     %1-1 to ML
%     X_train = data_array(:,1:end-1);
%     Y_train = data_array(:,end);
%     noleafNode = size(DAG,1);
%     
%     %1-2 algorithm
%     tic;
%     lambda = 1;
%     [W, ~, ~] = DFS_L21(X_train, data_array(:,end), lambda);
%     [~, feature_select] = sort(sum(W.*W,2),'descend');
%     time = toc*noleafNode;
%     vReducedFeaturesB = cell(1, noleafNode);
%     for ii = 1:noleafNode
%         vReducedFeaturesB{ii} = feature_select;
%     end
% 
%     vTime = time;
%     vSamples = size(data_array,1);
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+IP+fs+13Fisher
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'Fisher';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/13Fisher/';
% filePath = 'D:\Matlab\MFSIPMain\result\13Fisher\';
% 
% for i = 11:length(str_train_name)
%     %0 load
%     mat_name = str_train_name{i};
%     load (mat_name);
%     
%     %1-1 to ML
%     X_train = data_array(:,1:end-1);
%     Y_train = data_array(:,end);
%     noleafNode = size(DAG,1);
%     
%     %1-2 algorithm
%     tic;
%     feature_select = fisherselecte(X_train, Y_train, size(X_train,2));
%     time = toc*noleafNode;
%     feature_select = feature_select';
%     vReducedFeaturesB = cell(1, noleafNode);
%     for ii = 1:noleafNode
%         vReducedFeaturesB{ii} = feature_select;
%     end
% 
%     vTime = time;
%     vSamples = size(data_array,1);
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+IP+fs+14WOAFS
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'WOAFS';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/14WOAFS/';
% filePath = 'D:\Matlab\MFSIPMain\result\14WOAFS\';
% 
% for i = 11:length(str_train_name)
%     %0 load
%     mat_name = str_train_name{i};
%     load (mat_name);
%     
%     %1-1 to ML
%     X_train = data_array(:,1:end-1);
%     Y_train = data_array(:,end);
%     noleafNode = size(DAG,1);
%     
%     %1-2 algorithm
%     tic;
%     N = size(X_train, 2);
%     max_Iter = 20;
%     [~, feature_select, ~, ~] = jWOA(X_train, Y_train, N, max_Iter, cvpartition(Y_train,'HoldOut',0.2));
%     time = toc*noleafNode;
%     feature_select = feature_select';
%     vReducedFeaturesB = cell(1, noleafNode);
%     for ii = 1:noleafNode
%         vReducedFeaturesB{ii} = feature_select;
%     end
% 
%     vTime = time;
%     vSamples = size(data_array,1);
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+IP+fs+15SCAFS
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'SCAFS';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/15SCAFS/';
% filePath = 'D:\Matlab\MFSIPMain\result\15SCAFS\';
% 
% for i = 11:length(str_train_name)
%     %0 load
%     mat_name = str_train_name{i};
%     load (mat_name);
%     
%     %1-1 to ML
%     X_train = data_array(:,1:end-1);
%     Y_train = data_array(:,end);
%     noleafNode = size(DAG,1);
%     
%     %1-2 algorithm
%     tic;
%     N = size(X_train, 2);
%     max_Iter = 20;
%     alpha    = 2;
%     [~, feature_select, ~, ~] = jSCA(X_train, Y_train, N, max_Iter, alpha, cvpartition(Y_train,'HoldOut',0.2));
%     time = toc*noleafNode;
%     feature_select = feature_select';
%     vReducedFeaturesB = cell(1, noleafNode);
%     for ii = 1:noleafNode
%         vReducedFeaturesB{ii} = feature_select;
%     end
% 
%     vTime = time;
%     vSamples = size(data_array,1);
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% �����㷨�Ƚ�+acc
%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+11LCCSHFS+20%
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_LCCSHFS_Bridges.mat','fs_result_LCCSHFS_DD.mat','fs_result_LCCSHFS_CLEF.mat','fs_result_LCCSHFS_VOC.mat','fs_result_LCCSHFS_News20g.mat','fs_result_LCCSHFS_F194.mat','fs_result_LCCSHFS_ILSVRC65.mat','fs_result_LCCSHFS_Sun.mat','fs_result_LCCSHFS_Cifar100.mat','fs_result_LCCSHFS_Car196.mat','fs_result_LCCSHFS_Eisen.mat','fs_result_LCCSHFS_Derisi.mat','fs_result_LCCSHFS_Cellcycle.mat','fs_result_LCCSHFS_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'LCCSHFS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/11LCCSHFS/';
% % filePath = 'D:\Matlab\MFSIPMain\result\11LCCSHFS\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 11:length(str_mat_name)
%     if(i == 2)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, numSeleted, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, selectNum(i));
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     
%     vFeatureNum = numSeleted;
%     
%     method2 = 'SVM';
%     [~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, vFeatureNum, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, selectNum(i));
%     vF_1_SVM = FHMean_SVM;
%     vF_LCA_SVM = F_LCAMean_SVM;
%     vTIE_SVM = TIEmean_SVM;
%     
%     method3 = 'RF';
%     [~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, selectNum(i));
%     vF_1_RF = FHMean_RF;
%     vF_LCA_RF = F_LCAMean_RF;
%     vTIE_RF = TIEmean_RF;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+acc(+RF)+11LCCSHFS+10%-50%
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_LCCSHFS_Bridges.mat','fs_result_LCCSHFS_DD.mat','fs_result_LCCSHFS_CLEF.mat','fs_result_LCCSHFS_VOC.mat','fs_result_LCCSHFS_News20g.mat','fs_result_LCCSHFS_F194.mat','fs_result_LCCSHFS_ILSVRC65.mat','fs_result_LCCSHFS_Sun.mat','fs_result_LCCSHFS_Cifar100.mat','fs_result_LCCSHFS_Car196.mat','fs_result_LCCSHFS_Eisen.mat','fs_result_LCCSHFS_Derisi.mat','fs_result_LCCSHFS_Cellcycle.mat','fs_result_LCCSHFS_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'LCCSHFS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/11LCCSHFS/';
% % filePath = 'D:\Matlab\MFSIPMain\result\11LCCSHFS\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% selectNumArr = [0.1, 0.2, 0.3, 0.4, 0.5];
%     
% for i = 11:11%length(str_mat_name)
%     if(i == 2)
%         continue;
%     end
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
% 
%     mat_name = str_mat_name{i};
%     load (mat_name);
% 
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     
%     for ii = 2:2%length(selectNumArr)
%         vFeatureNumRate = selectNumArr(ii);
% 
%         %2 save
%         method1 = 'KNN';
%         [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, numSeleted, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, selectNumArr(ii));
%         vF_1_KNN = FHMean_KNN;
%         vF_LCA_KNN = F_LCAMean_KNN;
%         vTIE_KNN = TIEmean_KNN;
% 
%         vFeatureNum = numSeleted;
% 
%         method2 = 'SVM';
%         [~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, vFeatureNum, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, selectNumArr(ii));
%         vF_1_SVM = FHMean_SVM;
%         vF_LCA_SVM = F_LCAMean_SVM;
%         vTIE_SVM = TIEmean_SVM;
% 
%         method3 = 'RF';
%         [~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, selectNumArr(ii));
%         vF_1_RF = FHMean_RF;
%         vF_LCA_RF = F_LCAMean_RF;
%         vTIE_RF = TIEmean_RF;
% 
%         fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, int2str(ii)];
%         save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
%     end
% end

%% MFSIPMain.m+�����㷨�Ƚ�+SL+acc(+RF)+12DFS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_DFS_Bridges.mat','fs_result_DFS_DD.mat','fs_result_DFS_CLEF.mat','fs_result_DFS_VOC.mat','fs_result_DFS_News20g.mat','fs_result_DFS_F194.mat','fs_result_DFS_ILSVRC65.mat','fs_result_DFS_Sun.mat','fs_result_DFS_Cifar100.mat','fs_result_DFS_Car196.mat','fs_result_DFS_Eisen.mat','fs_result_DFS_Derisi.mat','fs_result_DFS_Cellcycle.mat','fs_result_DFS_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'DFS';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/12DFS/';
% filePath = 'D:\Matlab\MFSIPMain\result\12DFS\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 11:length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, numSeleted, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, selectNum(i));
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     
%     vFeatureNum = numSeleted;
%     
%     %method2 = 'SVM';
%     %[~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, vFeatureNum, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, selectNum(i));
%     vF_1_SVM = 0;
%     vF_LCA_SVM = 0;
%     vTIE_SVM = 0;
%     
%     %method3 = 'RF';
%     %[~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, selectNum(i));
%     vF_1_RF = 0;
%     vF_LCA_RF = 0;
%     vTIE_RF = 0;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+IP+acc(+RF)+13Fisher
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_Fisher_Bridges.mat','fs_result_Fisher_DD.mat','fs_result_Fisher_CLEF.mat','fs_result_Fisher_VOC.mat','fs_result_Fisher_News20g.mat','fs_result_Fisher_F194.mat','fs_result_Fisher_ILSVRC65.mat','fs_result_Fisher_Sun.mat','fs_result_Fisher_Cifar100.mat','fs_result_Fisher_Car196.mat','fs_result_Fisher_Eisen.mat','fs_result_Fisher_Derisi.mat','fs_result_Fisher_Cellcycle.mat','fs_result_Fisher_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'Fisher';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/13Fisher/';
% filePath = 'D:\Matlab\MFSIPMain\result\13Fisher\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 11:length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     vFeatureNumRate = selectNum(i);
%     
%     %2 save
%     method1 = 'KNN';
%     [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, numSeleted, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, selectNum(i));
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     
%     vFeatureNum = numSeleted;
%     
%     %method2 = 'SVM';
%     %[~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, vFeatureNum, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, selectNum(i));
%     vF_1_SVM = 0;
%     vF_LCA_SVM = 0;
%     vTIE_SVM = 0;
%     
%     %method3 = 'RF';
%     %[~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, selectNum(i));
%     vF_1_RF = 0;
%     vF_LCA_RF = 0;
%     vTIE_RF = 0;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+IP+acc(+RF)+14WOAFS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_WOAFS_Bridges.mat','fs_result_WOAFS_DD.mat','fs_result_WOAFS_CLEF.mat','fs_result_WOAFS_VOC.mat','fs_result_WOAFS_News20g.mat','fs_result_WOAFS_F194.mat','fs_result_WOAFS_ILSVRC65.mat','fs_result_WOAFS_Sun.mat','fs_result_WOAFS_Cifar100.mat','fs_result_WOAFS_Car196.mat','fs_result_WOAFS_Eisen.mat','fs_result_WOAFS_Derisi.mat','fs_result_WOAFS_Cellcycle.mat','fs_result_WOAFS_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'WOAFS';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/14WOAFS/';
% filePath = 'D:\Matlab\MFSIPMain\result\14WOAFS\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 11:length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     
%     numFeature = size(data_array, 2) - 1;
%     numSeleted = round(numFeature * selectNum(i));
%     if(length(size(vReducedFeaturesB{1},1)) < numSeleted)
%         numSeleted = size(vReducedFeaturesB{1},1);
%     end
%     vFeatureNum = numSeleted;
%     vFeatureNumRate = vFeatureNum/numFeature;
%     
%     %2 save
%     method1 = 'KNN';
%     [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, vFeatureNumRate);
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     
%     %method2 = 'SVM';
%     %[~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, vFeatureNumRate);
%     vF_1_SVM = 0;
%     vF_LCA_SVM = 0;
%     vTIE_SVM = 0;
%     
%     %method3 = 'RF';
%     %[~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, vFeatureNumRate);
%     vF_1_RF = 0;
%     vF_LCA_RF = 0;
%     vTIE_RF = 0;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+IP+acc(+RF)+15SCAFS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_SCAFS_Bridges.mat','fs_result_SCAFS_DD.mat','fs_result_SCAFS_CLEF.mat','fs_result_SCAFS_VOC.mat','fs_result_SCAFS_News20g.mat','fs_result_SCAFS_F194.mat','fs_result_SCAFS_ILSVRC65.mat','fs_result_SCAFS_Sun.mat','fs_result_SCAFS_Cifar100.mat','fs_result_SCAFS_Car196.mat','fs_result_SCAFS_Eisen.mat','fs_result_SCAFS_Derisi.mat','fs_result_SCAFS_Cellcycle.mat','fs_result_SCAFS_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'SCAFS';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/15SCAFS/';
% filePath = 'D:\Matlab\MFSIPMain\result\15SCAFS\';
% 
% selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 11:length(str_mat_name)
%     %0 load
%     data_test_name = str_test_name{i};
%     load (data_test_name);
%     
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     vTime = vTime; % vtime_Arr(selectNum(i));
%     vSamples = size(data_array,1);
%     vReducedFeaturesB = vReducedFeaturesB;
%     
%     numFeature = size(data_array, 2) - 1;
%     numSeleted = round(numFeature * selectNum(i));
%     if(length(size(vReducedFeaturesB{1},1)) < numSeleted)
%         numSeleted = size(vReducedFeaturesB{1},1);
%     end
%     vFeatureNum = numSeleted;
%     vFeatureNumRate = vFeatureNum/numFeature;
%     
%     %2 save
%     method1 = 'KNN';
%     [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, vFeatureNumRate);
%     vF_1_KNN = FHMean_KNN;
%     vF_LCA_KNN = F_LCAMean_KNN;
%     vTIE_KNN = TIEmean_KNN;
%     
%     %method2 = 'SVM';
%     %[~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, vFeatureNumRate);
%     vF_1_SVM = 0;
%     vF_LCA_SVM = 0;
%     vTIE_SVM = 0;
%     
%     %method3 = 'RF';
%     %[~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, vFeatureNumRate);
%     vF_1_RF = 0;
%     vF_LCA_RF = 0;
%     vTIE_RF = 0;
%     
%     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate');
% end

%% xlsд��+IP+ͼ�ṹ
% clc;
% clear All;
% 
% %0 ת������
% str_mat_name_cell = {'acc_result_LCCSHFS_Eisen.mat','acc_result_DFS_Eisen.mat','acc_result_Fisher_Eisen.mat','acc_result_WOAFS_Eisen.mat','acc_result_SCAFS_Eisen.mat','acc_result_MFSIP_Eisen.mat';...
%                      'acc_result_LCCSHFS_Derisi.mat','acc_result_DFS_Derisi.mat','acc_result_Fisher_Derisi.mat','acc_result_WOAFS_Derisi.mat','acc_result_SCAFS_Derisi.mat','acc_result_MFSIP_Derisi.mat';...
%                      'acc_result_LCCSHFS_Cellcycle.mat','acc_result_DFS_Cellcycle.mat','acc_result_Fisher_Cellcycle.mat','acc_result_WOAFS_Cellcycle.mat','acc_result_SCAFS_Cellcycle.mat','acc_result_MFSIP_Cellcycle.mat';...
%                      'acc_result_LCCSHFS_Gasch.mat','acc_result_DFS_Gasch.mat','acc_result_Fisher_Gasch.mat','acc_result_WOAFS_Gasch.mat','acc_result_SCAFS_Gasch.mat','acc_result_MFSIP_Gasch.mat'};
% str_classifier_arr = {'KNN','SVM','RF'};
% fileNameXls = {'MFSIP_reslut_acc_DAG','MFSIP_reslut_F_1_DAG','MFSIP_reslut_F_LCA_DAG','MFSIP_reslut_TIE_DAG'};
% 
% filePath = '/Users/lindashuai/Documents/MATLAB/';
% 
% [dataSetNumRow, algoNumColumn] = size(str_mat_name_cell);
% dataResultCell = cell(dataSetNumRow, algoNumColumn);
% for i = 1:dataSetNumRow
%     for j = 1:algoNumColumn
%         mat_name = str_mat_name_cell{i,j};
%         mat_name_data = load (mat_name);
%         
%         vac_KNN = 0;
%         vF_1_KNN = mat_name_data.vF_1_KNN;
%         vF_LCA_KNN = mat_name_data.vF_LCA_KNN;
%         vTIE_KNN = mat_name_data.vTIE_KNN;
% 
%         vac_SVM = 0;
%         vF_1_SVM = mat_name_data.vF_1_SVM;
%         vF_LCA_SVM = mat_name_data.vF_LCA_SVM;
%         vTIE_SVM = mat_name_data.vTIE_SVM;
% 
%         vac_RF = 0;
%         vF_1_RF = mat_name_data.vF_1_RF;
%         vF_LCA_RF = mat_name_data.vF_LCA_RF;
%         vTIE_RF = mat_name_data.vTIE_RF;
%         
%         str_classifier_arr_len = length(str_classifier_arr);
%         vac_mean = 0;
%         vF_1_mean = vF_1_KNN;
%         vF_LCA_mean = vF_LCA_KNN;
%         vTIE_mean = vTIE_KNN;
%         
% %         dataArr = [0,0,0,0;...
% %             vF_1_KNN,vF_1_KNN,vF_1_KNN,vF_1_mean;...
% %             vF_LCA_KNN,vF_LCA_KNN,vF_LCA_KNN,vF_LCA_mean;...
% %             vTIE_KNN,vTIE_KNN,vTIE_KNN,vTIE_mean];
%         dataArr = [0,0,0,0;...
%             vF_1_KNN,vF_1_SVM,vF_1_RF,vF_1_mean;...
%             vF_LCA_KNN,vF_LCA_SVM,vF_LCA_RF,vF_LCA_mean;...
%             vTIE_KNN,vTIE_SVM,vTIE_RF,vTIE_mean];
%         dataResultCell{i,j} = dataArr;
%     end
% end
% 
% %0-1 Ԥ��������
% dataHandleResultCell = cell(length(str_classifier_arr)+1, algoNumColumn);
% % str_data_name = {'Bridges','DD','CLEF','VOC'}; %,'News20g','Cifar100','ILSVRC65','Sun'
% for k = 1:algoNumColumn
%     for p = 1:dataSetNumRow
%         dataResultArr_k_p = dataResultCell{p,k};
%         [row, ~] = size(dataResultArr_k_p);
%         for r = 1:row
%             k_p = dataResultArr_k_p(r,:);
%             dataHandleResultCell{r,k} = [dataHandleResultCell{r,k}, k_p];
%         end
%     end
% end
% 
% %1 д������
% % for x = 1:data_row
% %     for y = 1:data_column
% %         dataHandled_x_y = dataHandled{x,y}';
% % 
% %         %1-0 ��ȡС������λ
% %         pointsNum = 4;
% %         dataBig = dataHandled_x_y*10^pointsNum;
% %         dataFloor = floor(dataBig);
% %         dataHandled_x_y = dataFloor*10^(-pointsNum);
% % 
% %         %1-1 ��xls
% %         beginIndexNum = 1+(x-1);
% %         beginIndex = 65+(y-1); %L
% %         
% %         beginIndexChar = char(beginIndex);
% % %         endIndexChar = char(endIndex);
% % 
% % %         indexBeginEnd = [beginIndexChar, num2str(beginIndexNum), ':', endIndex, num2str(endIndexNum)];
% %         indexBeginEnd = [beginIndexChar, num2str(beginIndexNum)];
% %         xlswrite([fileNameXls, '.csv'], dataHandled_x_y, 'Sheet1', indexBeginEnd);
% %     end
% % end
% 
% dataHandled = dataHandleResultCell;
% 
% %1-0 ��ȡС������λ
% % pointsNum = 4;
% % dataBig = dataHandled_x_y*10^pointsNum;
% % dataFloor = floor(dataBig);
% % dataHandled_x_y = dataFloor*10^(-pointsNum);
% 
% for l = 1:length(fileNameXls)
%     [~, column] = size(dataHandled);
%     
%     data_xls_l = cell(1,column);
%     for g = 1:column
%         dataHandledArr = dataHandled{l,g}';
%         data_xls_l{1,g} = dataHandledArr;
%     end
%     
%     %1-1 ��xls
%     beginIndexNum = 1;
%     beginIndex = 65; %L
% 
%     beginIndexChar = char(beginIndex);
%     endIndexChar = char(beginIndex+column);
% %     indexBeginEnd = [beginIndexChar, num2str(beginIndexNum), ':', endIndex, num2str(beginIndexNum)];
%     indexBeginEnd = [beginIndexChar, num2str(beginIndexNum)];
%     xlswrite([fileNameXls{l}, '.csv'], data_xls_l, 'Sheet1', indexBeginEnd);
% end

%% 1Friedman
% clc;
% clear;
% %0 k=8���㷨 N=8�����ݼ�
% %1 alpha=0.05, q_{alpha}=2.69.
% 
% %2 Friedman
% %Friedman test statistic
% %FF follows a Fisher distribution with (k-1) and (k-1)(N-1) , F(7,49)
% %F(7,49)=2.203;
% method = 'TIE'; % Acc_{H} %F_{LCA} %TIE
% % dataAcc = [];
% 
% % dataF1 = [0.3689 	0.3490 	0.3662 	0.3686 	0.3704 	0.3848 ;...
% %     0.3291 	0.3189 	0.3313 	0.3352 	0.3252 	0.3459 ;...
% %     0.3204 	0.3190 	0.3369 	0.3245 	0.3270 	0.3385 ;...
% %     0.3608 	0.3420 	0.3569 	0.3545 	0.3619 	0.3603 ];
% 
% % dataFLCA = [0.2119 	0.1895 	0.2121 	0.2097 	0.2122 	0.2278 ;...
% %     0.1712 	0.1641 	0.1744 	0.1781 	0.1738 	0.1874 ;...
% %     0.1778 	0.1756 	0.1923 	0.1818 	0.1828 	0.1914 ;...
% %     0.2055 	0.1833 	0.1990 	0.2018 	0.2051 	0.2038 ];
% 
% dataTIE = [1.1189 	1.2163 	1.1502 	1.1401 	1.1248 	1.0613 ;...
%     1.1875 	1.2512 	1.1849 	1.1947 	1.2219 	1.1782 ;...
%     1.1980 	1.1917 	1.1661 	1.1918 	1.1900 	1.1096 ;...
%     1.1071 	1.2136 	1.1682 	1.1893 	1.1579 	1.1455 ];
% 
% data = dataTIE;
% 
% [FF, averank, rank_w] = Friedman_test(data, method);
% a = 0;

%% xlsд��+ʱ�临�Ӷ� ���ṹ
% clc;
% clear All;
% 
% %0 ת������
% str_mat_name_cell = {'acc_result_HFSGKFS_Bridges.mat','acc_result_HiRRfam-FS_Bridges.mat','acc_result_HFSLDL_Bridges.mat','acc_result_HFSCN_Bridges.mat','acc_result_HFSDK_Bridges.mat','acc_result_HFSGR_Bridges.mat','acc_result_HFSLE_Bridges.mat','acc_result_MFSIP_Bridges.mat';...
%                      'acc_result_HFSGKFS_News20g.mat','acc_result_HiRRfam-FS_News20g.mat','acc_result_HFSLDL_News20g.mat','acc_result_HFSCN_News20g.mat','acc_result_HFSDK_News20g.mat','acc_result_HFSGR_News20g.mat','acc_result_HFSLE_News20g.mat','acc_result_MFSIP_News20g.mat';...
%                      'acc_result_HFSGKFS_ILSVRC65.mat','acc_result_HiRRfam-FS_ILSVRC65.mat','acc_result_HFSLDL_ILSVRC65.mat','acc_result_HFSCN_ILSVRC65.mat','acc_result_HFSDK_ILSVRC65.mat','acc_result_HFSGR_ILSVRC65.mat','acc_result_HFSLE_ILSVRC65.mat','acc_result_MFSIP_ILSVRC65.mat';...
%                      'acc_result_HFSGKFS_Sun.mat','acc_result_HiRRfam-FS_Sun.mat','acc_result_HFSLDL_Sun.mat','acc_result_HFSCN_Sun.mat','acc_result_HFSDK_Sun.mat','acc_result_HFSGR_Sun.mat','acc_result_HFSLE_Sun.mat','acc_result_MFSIP_Sun.mat';...
%                      'acc_result_HFSGKFS_Cifar100.mat','acc_result_HiRRfam-FS_Cifar100.mat','acc_result_HFSLDL_Cifar100.mat','acc_result_HFSCN_Cifar100.mat','acc_result_HFSDK_Cifar100.mat','acc_result_HFSGR_Cifar100.mat','acc_result_HFSLE_Cifar100.mat','acc_result_MFSIP_Cifar100.mat';...
%                      'acc_result_HFSGKFS_CLEF.mat','acc_result_HiRRfam-FS_CLEF.mat','acc_result_HFSLDL_CLEF.mat','acc_result_HFSCN_CLEF.mat','acc_result_HFSDK_CLEF.mat','acc_result_HFSGR_CLEF.mat','acc_result_HFSLE_CLEF.mat','acc_result_MFSIP_CLEF.mat'};
% 
% str_classifier_arr = {'KNN','SVM','RF'};
% fileNameXls = {'MFSIP_reslut_time'};
% 
% filePath = '/Users/lindashuai/Documents/MATLAB/';
% 
% [dataSetNumRow, algoNumColumn] = size(str_mat_name_cell);
% dataResultCell = cell(dataSetNumRow, algoNumColumn);
% for i = 1:dataSetNumRow
%     for j = 1:algoNumColumn
%         mat_name = str_mat_name_cell{i,j};
%         mat_name_data = load (mat_name);
%         
%         vac_mean = mat_name_data.vTime;
%         vF_1_mean = mat_name_data.vTime;
%         vF_LCA_mean = mat_name_data.vTime;
%         vTIE_mean = mat_name_data.vTime;
%         
%         dataArr = [0,0,0,vac_mean;...
%             0,0,0,vF_1_mean;...
%             0,0,0,vF_LCA_mean;...
%             0,0,0,vTIE_mean];
%         
%         dataResultCell{i,j} = dataArr;
%     end
% end
% 
% %0-1 Ԥ��������
% dataHandleResultCell = cell(length(str_classifier_arr)+1, algoNumColumn);
% % str_data_name = {'Bridges','DD','CLEF','VOC'}; %,'News20g','Cifar100','ILSVRC65','Sun'
% for k = 1:algoNumColumn
%     for p = 1:dataSetNumRow
%         dataResultArr_k_p = dataResultCell{p,k};
%         [row, ~] = size(dataResultArr_k_p);
%         for r = 1:row
%             k_p = dataResultArr_k_p(r,:);
%             dataHandleResultCell{r,k} = [dataHandleResultCell{r,k}, k_p];
%         end
%     end
% end
% 
% dataHandled = dataHandleResultCell;
% 
% %1-0 ��ȡС������λ
% for l = 1:length(fileNameXls)
%     [~, column] = size(dataHandled);
%     
%     data_xls_l = cell(1,column);
%     for g = 1:column
%         dataHandledArr = dataHandled{l,g}';
%         data_xls_l{1,g} = dataHandledArr;
%     end
%     
%     %1-1 ��xls
%     beginIndexNum = 1;
%     beginIndex = 65; %L
% 
%     beginIndexChar = char(beginIndex);
%     endIndexChar = char(beginIndex+column);
% %     indexBeginEnd = [beginIndexChar, num2str(beginIndexNum), ':', endIndex, num2str(beginIndexNum)];
%     indexBeginEnd = [beginIndexChar, num2str(beginIndexNum)];
%     xlswrite([fileNameXls{l}, '.csv'], data_xls_l, 'Sheet1', indexBeginEnd);
% end

%Eisen 1283 863(3574)
%Derisi 1539 1058(4120)
%Cellcycle 1544 1064(4126)
%Gasch 1546 1064(4132)
%% MFSIPMain.m+�����㷨�Ƚ�+IP+acc(+RF)�¼����Ӷ�+12DFS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_DFS_Bridges.mat','fs_result_DFS_DD.mat','fs_result_DFS_CLEF.mat','fs_result_DFS_VOC.mat','fs_result_DFS_News20g.mat','fs_result_DFS_F194.mat','fs_result_DFS_ILSVRC65.mat','fs_result_DFS_Sun.mat','fs_result_DFS_Cifar100.mat','fs_result_DFS_Car196.mat','fs_result_DFS_Eisen.mat','fs_result_DFS_Derisi.mat','fs_result_DFS_Cellcycle.mat','fs_result_DFS_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'DFS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/12DFS/';
% % filePath = 'D:\Matlab\MFSIPMain\result\12DFS\';
% 
% for i = 11:length(str_mat_name)
%     %0 load
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     if(i == 11)
%         vTime = vTime / 3574;
%         vTime = vTime * 863;
%     elseif(i == 12)
%         vTime = vTime / 4120;
%         vTime = vTime * 1058;
%     elseif(i == 13)
%         vTime = vTime / 4126;
%         vTime = vTime * 1064;
%     else
%         vTime = vTime / 4132;
%         vTime = vTime * 1064;
%     end
%     vSamples = vSamples;
%     vReducedFeaturesB = vReducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+IP+acc(+RF)�¼����Ӷ�+13Fisher
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_Fisher_Bridges.mat','fs_result_Fisher_DD.mat','fs_result_Fisher_CLEF.mat','fs_result_Fisher_VOC.mat','fs_result_Fisher_News20g.mat','fs_result_Fisher_F194.mat','fs_result_Fisher_ILSVRC65.mat','fs_result_Fisher_Sun.mat','fs_result_Fisher_Cifar100.mat','fs_result_Fisher_Car196.mat','fs_result_Fisher_Eisen.mat','fs_result_Fisher_Derisi.mat','fs_result_Fisher_Cellcycle.mat','fs_result_Fisher_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'Fisher';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/13Fisher/';
% % filePath = 'D:\Matlab\MFSIPMain\result\13Fisher\';
% 
% for i = 11:length(str_mat_name)
%     %0 load
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     if(i == 11)
%         vTime = vTime / 3574;
%         vTime = vTime * 863;
%     elseif(i == 12)
%         vTime = vTime / 4120;
%         vTime = vTime * 1058;
%     elseif(i == 13)
%         vTime = vTime / 4126;
%         vTime = vTime * 1064;
%     else
%         vTime = vTime / 4132;
%         vTime = vTime * 1064;
%     end
%     vSamples = vSamples;
%     vReducedFeaturesB = vReducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+IP+acc(+RF)�¼����Ӷ�+14WOAFS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_WOAFS_Bridges.mat','fs_result_WOAFS_DD.mat','fs_result_WOAFS_CLEF.mat','fs_result_WOAFS_VOC.mat','fs_result_WOAFS_News20g.mat','fs_result_WOAFS_F194.mat','fs_result_WOAFS_ILSVRC65.mat','fs_result_WOAFS_Sun.mat','fs_result_WOAFS_Cifar100.mat','fs_result_WOAFS_Car196.mat','fs_result_WOAFS_Eisen.mat','fs_result_WOAFS_Derisi.mat','fs_result_WOAFS_Cellcycle.mat','fs_result_WOAFS_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'WOAFS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/14WOAFS/';
% % filePath = 'D:\Matlab\MFSIPMain\result\14WOAFS\';
% 
% for i = 11:length(str_mat_name)
%     %0 load
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     if(i == 11)
%         vTime = vTime / 3574;
%         vTime = vTime * 863;
%     elseif(i == 12)
%         vTime = vTime / 4120;
%         vTime = vTime * 1058;
%     elseif(i == 13)
%         vTime = vTime / 4126;
%         vTime = vTime * 1064;
%     else
%         vTime = vTime / 4132;
%         vTime = vTime * 1064;
%     end
%     vSamples = vSamples;
%     vReducedFeaturesB = vReducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% MFSIPMain.m+�����㷨�Ƚ�+IP+acc(+RF)�¼����Ӷ�+15SCAFS
% clc;
% clear All;
% 
% str_mat_name = {'fs_result_SCAFS_Bridges.mat','fs_result_SCAFS_DD.mat','fs_result_SCAFS_CLEF.mat','fs_result_SCAFS_VOC.mat','fs_result_SCAFS_News20g.mat','fs_result_SCAFS_F194.mat','fs_result_SCAFS_ILSVRC65.mat','fs_result_SCAFS_Sun.mat','fs_result_SCAFS_Cifar100.mat','fs_result_SCAFS_Car196.mat','fs_result_SCAFS_Eisen.mat','fs_result_SCAFS_Derisi.mat','fs_result_SCAFS_Cellcycle.mat','fs_result_SCAFS_Gasch.mat'};
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% 
% algorithmName = 'SCAFS';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/15SCAFS/';
% % filePath = 'D:\Matlab\MFSIPMain\result\15SCAFS\';
% 
% for i = 11:length(str_mat_name)
%     %0 load
%     mat_name = str_mat_name{i};
%     load (mat_name);
%     
%     if(i == 11)
%         vTime = vTime / 3574;
%         vTime = vTime * 863;
%     elseif(i == 12)
%         vTime = vTime / 4120;
%         vTime = vTime * 1058;
%     elseif(i == 13)
%         vTime = vTime / 4126;
%         vTime = vTime * 1064;
%     else
%         vTime = vTime / 4132;
%         vTime = vTime * 1064;
%     end
%     vSamples = vSamples;
%     vReducedFeaturesB = vReducedFeaturesB;
%     
%     %2 save
%     fileName = [str_function_name{1}, algorithmName, '_', str_data_name{i}];
%     save([filePath, fileName], 'vTime', 'vSamples', 'vReducedFeaturesB');
% end

%% xlsд��+ʱ�临�Ӷ�IP ͼ�ṹ
% clc;
% clear All;
% 
% %0 ת������
% str_mat_name_cell = {'fs_result_LCCSHFS_Eisen.mat','fs_result_DFS_Eisen.mat','fs_result_Fisher_Eisen.mat','fs_result_WOAFS_Eisen.mat','fs_result_SCAFS_Eisen.mat','fs_result_MFSIP_Eisen.mat';...
%                      'fs_result_LCCSHFS_Derisi.mat','fs_result_DFS_Derisi.mat','fs_result_Fisher_Derisi.mat','fs_result_WOAFS_Derisi.mat','fs_result_SCAFS_Derisi.mat','fs_result_MFSIP_Derisi.mat';...
%                      'fs_result_LCCSHFS_Cellcycle.mat','fs_result_DFS_Cellcycle.mat','fs_result_Fisher_Cellcycle.mat','fs_result_WOAFS_Cellcycle.mat','fs_result_SCAFS_Cellcycle.mat','fs_result_MFSIP_Cellcycle.mat';...
%                      'fs_result_LCCSHFS_Gasch.mat','fs_result_DFS_Gasch.mat','fs_result_Fisher_Gasch.mat','fs_result_WOAFS_Gasch.mat','fs_result_SCAFS_Gasch.mat','fs_result_MFSIP_Gasch.mat'};
% 
% str_classifier_arr = {'KNN','SVM','RF'};
% fileNameXls = {'MFSIP_reslut_time_IP_DAG'};
% 
% filePath = '/Users/lindashuai/Documents/MATLAB/';
% 
% [dataSetNumRow, algoNumColumn] = size(str_mat_name_cell);
% dataResultCell = cell(dataSetNumRow, algoNumColumn);
% for i = 1:dataSetNumRow
%     for j = 1:algoNumColumn
%         mat_name = str_mat_name_cell{i,j};
%         mat_name_data = load (mat_name);
%         
%         if(j == 1)
%             vac_mean = sum(mat_name_data.vTime);
%             vF_1_mean = sum(mat_name_data.vTime);
%             vF_LCA_mean = sum(mat_name_data.vTime);
%             vTIE_mean = sum(mat_name_data.vTime);
%         else
%             vac_mean = mat_name_data.vTime;
%             vF_1_mean = mat_name_data.vTime;
%             vF_LCA_mean = mat_name_data.vTime;
%             vTIE_mean = mat_name_data.vTime;
%         end
%         
%         dataArr = [0,0,0,vac_mean;...
%             0,0,0,vF_1_mean;...
%             0,0,0,vF_LCA_mean;...
%             0,0,0,vTIE_mean];
%         
%         dataResultCell{i,j} = dataArr;
%     end
% end
% 
% %0-1 Ԥ��������
% dataHandleResultCell = cell(length(str_classifier_arr)+1, algoNumColumn);
% % str_data_name = {'Bridges','DD','CLEF','VOC'}; %,'News20g','Cifar100','ILSVRC65','Sun'
% for k = 1:algoNumColumn
%     for p = 1:dataSetNumRow
%         dataResultArr_k_p = dataResultCell{p,k};
%         [row, ~] = size(dataResultArr_k_p);
%         for r = 1:row
%             k_p = dataResultArr_k_p(r,:);
%             dataHandleResultCell{r,k} = [dataHandleResultCell{r,k}, k_p];
%         end
%     end
% end
% 
% dataHandled = dataHandleResultCell;
% 
% %1-0 ��ȡС������λ
% for l = 1:length(fileNameXls)
%     [~, column] = size(dataHandled);
%     
%     data_xls_l = cell(1,column);
%     for g = 1:column
%         dataHandledArr = dataHandled{l,g}';
%         data_xls_l{1,g} = dataHandledArr;
%     end
%     
%     %1-1 ��xls
%     beginIndexNum = 1;
%     beginIndex = 65; %L
% 
%     beginIndexChar = char(beginIndex);
%     endIndexChar = char(beginIndex+column);
% %     indexBeginEnd = [beginIndexChar, num2str(beginIndexNum), ':', endIndex, num2str(beginIndexNum)];
%     indexBeginEnd = [beginIndexChar, num2str(beginIndexNum)];
%     xlswrite([fileNameXls{l}, '.csv'], data_xls_l, 'Sheet1', indexBeginEnd);
% end

%% MFSIP+��ֵ��ͼ
% clear;
% clc;
% 
% x = -1.0:0.1:1.3; 
% y = -1.0:0.1:1.3;
% [X,Y] = meshgrid(x,y); 
% Z = -X.*exp(-X.^2-Y.^4)*1;
% % Z=sin(Y-1.3).*cos(X*2-1.3);
% [C,h] = contour(Z); % ��ʾ�ݶȣ����һ�ȡ�ݶ����ݽ��в��� contour contourf
% clabel(C,h); % ��ʾ�ݶȵ�ֵ
% 
% set(gca,'FontName','Times New Roman','FontSize',16);
% % xlabel('Z_i');
% ylabel('F_i');
% set(gca, 'YTickLabel', 'F_i', 'FontSize', 23, 'FontName', 'Times New Roman');
% title('J(Z_i,F_i)');

%% MFSIP+�ȶ�ά����ͼ
% clear;
% clc;
% 
% x = linspace(0.5,1.8*pi,100);
% y1 = sin(x);
% 
% plot(x,y1)
% axis([0.5, 2*pi, -1.3, 1.3]);
% set(gca,'FontName','Times New Roman','FontSize',23);
% xlabel('Z_i');
% ylabel('iteration number');
% title('J(Z_i,F_i)');

%% xlsд��+ʱ�临�Ӷ� ����ͼ ͼ�ṹ
% clear;
% clc;
% 
% algorithmArr = {'LCCSHFS','DFS','Fisher','WOAFS','SCAFS','MFSIP'};
% algorithmDatArr = {'Eisen','Derisi','Cellcycle','Gasch'};
% Xticklabels = {'','Eisen','Derisi','Cellcycle','Gasch','',''};
% 
% algorithmRTimeCell = [
%     16.0110,70.8620,76.5410,10189.0000,7483.6000,1.7469;...
%     15.4380,18.2710,71.9930,14646.0000,13868.0000,0.3289;...
%     20.2120,18.6640,86.0620,18056.0000,17321.0000,1.6916;...
%     20.2120,18.6640,86.0620,18056.0000,17321.0000,1.6916];
% % algorithmStyleArr = {'-k','-y','-m','-c','-b','-g','-r'};
% algorithmStyleArr = {'-k','-y','-m','-c','-b','-r'};
% 
% xMax = length(algorithmArr); % �㷨����6��
% yMax = round(max(max(algorithmRTimeCell)) / 10000) * 10000;
% x = 1:1:length(algorithmDatArr); % ���ݼ�����4��
% 
% for i = 1:length(algorithmArr)
%     algorithmRTimeCellTemp = algorithmRTimeCell';
%     plot(x,algorithmRTimeCellTemp(i,1:end),algorithmStyleArr{i},'LineWidth',2,'MarkerSize',10);
%     hold on;
% end
% 
% axis([0,xMax,0,yMax])  %ȷ��x����y���ͼ��С
% % set(gca,'XTick',[0:1:xMax+2]) %x�᷶Χ1-6�����1
% set(gca, 'XTickLabel', algorithmDatArr, 'FontSize', 16, 'FontName', 'Times New Roman');
% set(gca, 'YTick',[0:yMax/length(algorithmDatArr)+1:yMax]) %y�᷶Χ0-700�����100
% 
% set(gca,'Xticklabel',Xticklabels);
% 
% legend(algorithmArr); % ���ϽǱ�ע����
% xlabel(['\fontname{Times New Roman}\fontsize{20}', 'Datasets']);
% ylabel(['\fontname{Times New Roman}\fontsize{20}', 'R-Time']);

%% xlsд��+ʱ�临�Ӷ� ����ͼ ���ṹ
% clear;
% clc;
% 
% algorithmArr = {'HFSGKFS','HiRRfam','HFSLDL','HFSCN','HFSDK','HFSGR','HFSLE','MFSIP'};
% algorithmDatArr = {'Bridges','News20g','ILSVRC65','Sun','Cifar100','Car196'};
% Xticklabels = {'','Bridges','News20g','ILSVRC65','Sun','Cifar100','Car196','',''};
% 
% algorithmRTimeCell = [
%     0.0642,0.0133,0.0166,0.0696,0.3553,0.0154,0.5989,0.0015 ;...
%     896.5600,120000,120000,120000,120000,114860.0000,120000,1170.8000 ;...
%     12177.0000,388.4800,70.1260,292.0800,1712.9000,172.8800,1177.3000,58.0890 ;...
%     39750.0000,2185.3000,343.5300,936.9600,6216.6000,449.3800,2133.2000,230.9500 ;...
%     22623.0000,9709.8000,404.1000,893.3000,5798.3000,538.0900,786.6500,181.7900 ;...
%     8931.9000,2301.7000,90.4860,141.5100,656.1600,261.8100,191.5800,55.5390 ];
% algorithmStyleArr = {'-k','-y','-m','-c','-b','-g','-c','-r'};
% 
% xMax = length(algorithmArr); % �㷨����6��
% yMax = 120000;
% x = 1:1:length(algorithmDatArr); % ���ݼ�����4��
% 
% for i = 1:length(algorithmArr)
%     algorithmRTimeCellTemp = algorithmRTimeCell';
%     plot(x,algorithmRTimeCellTemp(i,1:end),algorithmStyleArr{i},'LineWidth',2,'MarkerSize',10);
%     hold on;
% end
% 
% axis([0,xMax,0,yMax])  %ȷ��x����y���ͼ��С
% % set(gca,'XTick',[0:1:xMax+2]) %x�᷶Χ1-6�����1
% set(gca, 'XTickLabel', algorithmDatArr, 'FontSize', 16, 'FontName', 'Times New Roman');
% set(gca, 'YTick',[0:yMax/length(algorithmDatArr)+1:yMax]) %y�᷶Χ0-700�����100
% 
% set(gca,'Xticklabel',Xticklabels);
% 
% legend(algorithmArr); % ���ϽǱ�ע����
% xlabel(['\fontname{Times New Roman}\fontsize{20}', 'Datasets']);
% ylabel(['\fontname{Times New Roman}\fontsize{20}', 'R-Time']);
% 

%% ��ͬ�����Լ̳����̬���Ӱ��
%% MFSIPMain.m+fs+acc(+RF)+ͼ�ṹ
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% % selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 13:length(str_data_name)
%     
%     %Eisen (alphaArr_i == 2 && betaArr_i == 2)    ok
%     %Derisi (alphaArr_i == 2 && betaArr_i == 2)   ok
%     %Cellcycle (alphaArr_i == 2 && betaArr_i == 2)
%     %Gasch (alphaArr_i == 5 && betaArr_i == 5)
%     
%     for alphaArr_i = 1:length(alphaArr)
%         for betaArr_i = 1:length(betaArr)
%             if(i == length(str_data_name))
%                 if ((alphaArr_i == 5 && betaArr_i == 5) || (alphaArr_i == 5 && betaArr_i == 6) || (alphaArr_i == 6 && betaArr_i == 5))
% 
%                     selectNumPersen = [0.1, 0.2, 0.3, 0.4, 0.5, 1];
%                     for j = 1:length(selectNumPersen)
%                         if(j == 2)
%                             continue;
%                         end
%                         %0 load
%                         data_test_name = str_test_name{i};
%                         load (data_test_name);
% 
%                         data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
% 
%                         mat_name = [str_function_name{1}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%                         load (mat_name);
% 
%                         vTime = vTime; % vtime_Arr(selectNum(i));
%                         vSamples = size(data_array,1);
%                         vReducedFeaturesB = vReducedFeaturesB;
%                         vFeatureNumRate = selectNumPersen(j);
%                         vAlpha = vAlpha;
%                         vBeta = vBeta;
% 
%                         %2 save
%                         method1 = 'KNN';
%                         [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, numSeleted, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, vFeatureNumRate);
%                         vF_1_KNN = FHMean_KNN;
%                         vF_LCA_KNN = F_LCAMean_KNN;
%                         vTIE_KNN = TIEmean_KNN;
% 
%                         vFeatureNum = numSeleted;
% 
%                         method2 = 'SVM';
%                         [~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, vFeatureNum, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, vFeatureNumRate);
%                         vF_1_SVM = FHMean_SVM;
%                         vF_LCA_SVM = F_LCAMean_SVM;
%                         vTIE_SVM = TIEmean_SVM;
% 
%                         method3 = 'RF';
%                         [~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, vFeatureNumRate);
%                         vF_1_RF = FHMean_RF;
%                         vF_LCA_RF = F_LCAMean_RF;
%                         vTIE_RF = TIEmean_RF;
% 
%                         fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i), '_', int2str(j)];
%                         save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate', 'vAlpha', 'vBeta');
%                     end
%                 end
% 
%             else
%                 
%                 if ((alphaArr_i == 2 && betaArr_i == 2) || (alphaArr_i == 2 && betaArr_i == 6) || (alphaArr_i == 6 && betaArr_i == 2))
% 
%                     selectNumPersen = [0.1, 0.2, 0.3, 0.4, 0.5, 1];
%                     for j = 1:length(selectNumPersen)
%                         if(j == 2)
%                             continue;
%                         end
%                         %0 load
%                         data_test_name = str_test_name{i};
%                         load (data_test_name);
% 
%                         data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
% 
%                         mat_name = [str_function_name{1}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%                         load (mat_name);
% 
%                         vTime = vTime; % vtime_Arr(selectNum(i));
%                         vSamples = size(data_array,1);
%                         vReducedFeaturesB = vReducedFeaturesB;
%                         vFeatureNumRate = selectNumPersen(j);
%                         vAlpha = vAlpha;
%                         vBeta = vBeta;
% 
%                         %2 save
%                         method1 = 'KNN';
%                         [~, ~, FHMean_KNN, F_LCAMean_KNN, TIEmean_KNN, numSeleted, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method1, vFeatureNumRate);
%                         vF_1_KNN = FHMean_KNN;
%                         vF_LCA_KNN = F_LCAMean_KNN;
%                         vTIE_KNN = TIEmean_KNN;
% 
%                         vFeatureNum = numSeleted;
% 
%                         method2 = 'SVM';
%                         [~, ~, FHMean_SVM, F_LCAMean_SVM, TIEmean_SVM, vFeatureNum, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method2, vFeatureNumRate);
%                         vF_1_SVM = FHMean_SVM;
%                         vF_LCA_SVM = F_LCAMean_SVM;
%                         vTIE_SVM = TIEmean_SVM;
% 
%                         method3 = 'RF';
%                         [~, ~, FHMean_RF, F_LCAMean_RF, TIEmean_RF, ~, ~] = HierDAGSVMPredictionBatch_IP(data_array, DAG, vReducedFeaturesB, method3, vFeatureNumRate);
%                         vF_1_RF = FHMean_RF;
%                         vF_LCA_RF = F_LCAMean_RF;
%                         vTIE_RF = TIEmean_RF;
% 
%                         fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i), '_', int2str(j)];
%                         save([filePath, fileName], 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate', 'vAlpha', 'vBeta');
%                     end
%                 end
%             end
%         end
%     end
% end

%% MFSIPMain.m+fs+acc(+RF)+���ṹ
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% 
% algorithmName = 'MFSIP';
% % filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% % selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 1:9%length(str_mat_name)
%     if(i == 2 || i == 3 || i == 4 || i == 5 || i == 6)
%         continue;
%     end
%     if(i == 1 || i == 8) % Bridges % Sun ��Ҫ
%         continue;
%     end
%     
%     %Bridges (alphaArr_i == 3 && betaArr_i == 4)
%     %ILSVRC65 (alphaArr_i == 5 && betaArr_i == 1) ok
%     %Sun (alphaArr_i == 5 && betaArr_i == 1)
%     %Cifar100 (alphaArr_i == 5 && betaArr_i == 1)  ok
%     
%     %Eisen (alphaArr_i == 2 && betaArr_i == 2)    ok
%     %Derisi (alphaArr_i == 2 && betaArr_i == 2)   ok
%     %Cellcycle (alphaArr_i == 2 && betaArr_i == 2)
%     %Gasch (alphaArr_i == 5 && betaArr_i == 5)
%     
%     for alphaArr_i = 1:length(alphaArr)
%         for betaArr_i = 1:length(betaArr)
%             if ((alphaArr_i == 5 && betaArr_i == 1) || (alphaArr_i == 5 && betaArr_i == 6) || (alphaArr_i == 6 && betaArr_i == 1))
% 
%                 selectNumPersen = [0.1, 0.2, 0.3, 0.4, 0.5, 1];
%                 for j = 1:length(selectNumPersen)
%                     if(j == 2)
%                         continue;
%                     end
%                     %0 load
%                     data_test_name = str_test_name{i};
%                     load (data_test_name);
% 
%                     data_array = MFSIP_DataHandle(data_array); %% �ȹ�һ��
% 
%                     mat_name = [str_function_name{1}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i)];
%                     load (mat_name);
% 
%                     vTime = vTime; % vtime_Arr(selectNum(i));
%                     vSamples = size(data_array,1);
%                     vReducedFeaturesB = vReducedFeaturesB;
%                     vFeatureNumRate = selectNumPersen(j);
%                     vAlpha = vAlpha;
%                     vBeta = vBeta;
% 
%                     %2 save
%                     method1 = 'KNN';
%                     [accuracyMean_KNN, accuracyStd_KNN, ~, FHMean_KNN, FHStd_KNN, F_LCAMean_KNN, F_LCAStd_KNN, ~, TIEmean_KNN, TIEStd_KNN, ~, numSeleted] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method1, vFeatureNumRate);
%                     vac_KNN = accuracyMean_KNN;
%                     vF_1_KNN = FHMean_KNN;
%                     vF_LCA_KNN = F_LCAMean_KNN;
%                     vTIE_KNN = TIEmean_KNN;
%                     vac_Std_KNN = accuracyStd_KNN;
%                     vF_1_Std_KNN = FHStd_KNN;
%                     vF_LCA_Std_KNN = F_LCAStd_KNN;
%                     vTIE_Std_KNN = TIEStd_KNN;
% 
%                     vFeatureNum = numSeleted;
% 
%                     method2 = 'SVM';
%                     [accuracyMean_SVM, accuracyStd_SVM, ~, FHMean_SVM, FHStd_SVM, F_LCAMean_SVM, F_LCAStd_SVM, ~, TIEmean_SVM, TIEStd_SVM, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method2, vFeatureNumRate);
%                     vac_SVM = accuracyMean_SVM;
%                     vF_1_SVM = FHMean_SVM;
%                     vF_LCA_SVM = F_LCAMean_SVM;
%                     vTIE_SVM = TIEmean_SVM;
%                     vac_Std_SVM = accuracyStd_SVM;
%                     vF_1_Std_SVM = FHStd_SVM;
%                     vF_LCA_Std_SVM = F_LCAStd_SVM;
%                     vTIE_Std_SVM = TIEStd_SVM;
% 
%                     method3 = 'RF';
%                     [accuracyMean_RF, accuracyStd_RF, ~, FHMean_RF, FHStd_RF, F_LCAMean_RF, F_LCAStd_RF, ~, TIEmean_RF, TIEStd_RF, ~, ~] = HierMainPredictionBatchIP(data_array, tree, vReducedFeaturesB, method3, vFeatureNumRate);
%                     vac_RF = accuracyMean_RF;
%                     vF_1_RF = FHMean_RF;
%                     vF_LCA_RF = F_LCAMean_RF;
%                     vTIE_RF = TIEmean_RF;
%                     vac_Std_RF = accuracyStd_RF;
%                     vF_1_Std_RF = FHStd_RF;
%                     vF_LCA_Std_RF = F_LCAStd_RF;
%                     vTIE_Std_RF = TIEStd_RF;
% 
%                     fileName = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i), '_', int2str(j)];
%                     save([filePath, fileName], 'vac_KNN', 'vF_1_KNN', 'vF_LCA_KNN', 'vTIE_KNN','vac_Std_KNN', 'vF_1_Std_KNN', 'vF_LCA_Std_KNN', 'vTIE_Std_KNN', 'vac_SVM', 'vF_1_SVM', 'vF_LCA_SVM', 'vTIE_SVM', 'vac_Std_SVM', 'vF_1_Std_SVM', 'vF_LCA_Std_SVM', 'vTIE_Std_SVM', 'vac_RF', 'vF_1_RF', 'vF_LCA_RF', 'vTIE_RF', 'vac_Std_RF', 'vF_1_Std_RF', 'vF_LCA_Std_RF', 'vTIE_Std_RF', 'vTime', 'vSamples', 'vReducedFeaturesB', 'vFeatureNum', 'vFeatureNumRate', 'vAlpha', 'vBeta');
%                 end
%             end
%         end
%     end
% end

%% MFSIPMain.m+fs+acc(+RF)+ͼ�ṹ+��״ͼ F_1+KNN F_{LCA}+KNN
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% str_classifier_arr = {'M-KNN','M-SVM','M-RF'};
% str_function_name_F = {'Acc_M','F_1','F_{LCA}','TIE'};
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% % selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 11:13%length(str_mat_name)
%     if(i == 12)
%         continue;
%     end
%     %Eisen (alphaArr_i == 2 && betaArr_i == 2)    ok
%     %Derisi (alphaArr_i == 2 && betaArr_i == 2)   ok
%     %Cellcycle (alphaArr_i == 2 && betaArr_i == 2)
%     %Gasch (alphaArr_i == 5 && betaArr_i == 5)
%     
%     %%%% ����ı�
%     str_classifier = str_classifier_arr{1};
%     str_function_F = str_function_name_F{2};
%     
%     selectNumPersen = [0.1, 0.2, 0.3, 0.4, 0.5, 1];
%     x = [1,2,3,4,5,6]; % x�������
%     xLables = ['10%' ; '20%'; '30%'; '40%'; '50%'; 'All'];
%     
%     dataCell = [];
%     for j = 1:length(selectNumPersen)
%         dataArr = [0,0,0];
%         
%         for alphaArr_i = 1:length(alphaArr)
%             for betaArr_i = 1:length(betaArr)
%                 
%                 if(i == length(str_data_name))
%                     if ((alphaArr_i == 5 && betaArr_i == 5) || (alphaArr_i == 5 && betaArr_i == 6) || (alphaArr_i == 6 && betaArr_i == 5))
% %                         %0 load
% %                         mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i), '_', int2str(j)];
% %                         mat_name_data = load (mat_name);
% % 
% %                         %%%% ����ı�
% %                         %(mat_name_data.vF_LCA_KNN + mat_name_data.vF_LCA_SVM + mat_name_data.vF_LCA_RF) / length(str_classifier_arr);
% %                         %data = mat_name_data.vF_1_KNN;
% %                         data = mat_name_data.vF_LCA_KNN;
% % 
% %                         if (alphaArr_i == 2 && betaArr_i == 2)
% %                             dataArr(1) = data;
% %                         end
% %                         if(alphaArr_i == 2 && betaArr_i == 6)
% %                             dataArr(2) = data;
% %                         end
% %                         if(alphaArr_i == 6 && betaArr_i == 2)
% %                             dataArr(3) = data;
% %                         end
%                     end
%                 else
%                     if ((alphaArr_i == 2 && betaArr_i == 2) || (alphaArr_i == 2 && betaArr_i == 6) || (alphaArr_i == 6 && betaArr_i == 2))
%                         %0 load
%                         mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i), '_', int2str(j)];
%                         mat_name_data = load (mat_name);
% 
%                         %%%% ����ı�
%                         %(mat_name_data.vF_LCA_KNN + mat_name_data.vF_LCA_SVM + mat_name_data.vF_LCA_RF) / length(str_classifier_arr);
%                         %data = mat_name_data.vF_1_KNN;
%                         data = mat_name_data.vF_1_KNN;
% 
%                         if (alphaArr_i == 2 && betaArr_i == 2)
%                             dataArr(1) = data;
%                         end
%                         if(alphaArr_i == 2 && betaArr_i == 6)
%                             dataArr(2) = data;
%                         end
%                         if(alphaArr_i == 6 && betaArr_i == 2)
%                             dataArr(3) = data;
%                         end
%                     end
%                 end
%                 
%                 
%             end
%         end
%         dataCell = [dataCell; dataArr];
%     end
%     
%     legendName = ["MFSIP(��,��)","MFSIP(��)","MFSIP(��)"];
% 
%     % x����
%     XX = dataCell; %[1,3.92,2.78;1,6.63,4.2;9.98,22.15,15.46;9.98,22.15,15.46;9.98,22.15,15.46;9.98,22.15,15.46];
% 
%     figure1 = figure(1);
% 
%     %1 ��
%     h = bar(XX, 'FaceColor', 'flat');
% %     mycolor = [102,128,255;255,179,102;255,255,153]./255;
%     mycolor = [155,127,160;205,150,155;200,200,227]./255;
%     for k = 1:size(XX,2)
%         h(k).FaceColor = mycolor(k,:);
%     end
%     
%     FontSize = 24;
%     set(gca, 'XTick', x, 'XTickLabel', xLables);
%     set(gca,'FontSize',FontSize,'Fontname', 'Times New Roman');
%     
%     if(i == 11)
%         aaa = 90;
%     else
%         aaa = 80;
%     end
%     max_y = max(max(dataCell));
%     min_y = min(min(dataCell));
%     max1 = aaa*max_y;
%     min1 = aaa*min_y;
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     str = "123";
%     if(i == 11)
%         str = "Number of features (c)";
%     else
%         str = "Number of features (d)";
%     end
%     xlabel(str,'Fontname', 'Times New Roman','FontSize',FontSize);
%     ylabel([str_function_F,'(', str_classifier,')'],'Fontname', 'Times New Roman','FontSize',FontSize);
%     %ylabel([str_function_F,'(', str_classifier,')'],'Fontname', 'Times New Roman','FontSize',FontSize);
% 
% %     hl = legend(legendName);
% %     set(hl,'Orientation','horizon');
% %     set(hl,'Box','on', 'location','NorthEast', 'FontSize',FontSize, 'FontName','Times New Roman');    
%     ax1 = gca;
%     %ax1.LineWidth = 1;
% 
%     fileName_result = [int2str(2), '_', algorithmName, '_', str_classifier, '_', str_function_F, '_fig_', str_data_name{i}];
%     saveas(figure1, strcat([filePath, fileName_result], '.png')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     close(figure1);
% end

%% MFSIPMain.m+fs+acc(+RF)+���ṹ+��״ͼ F_1+KNN F_{LCA}+KNN
% clc;
% clear All;
% 
% str_data_name = {'Bridges','DD','CLEF','VOC','News20g','F194','ILSVRC65','Sun','Cifar100','Car196','Eisen','Derisi','Cellcycle','Gasch'};
% str_train_name = {'BridgesTrain.mat','DDTrain.mat','CLEFTrain.mat','VOCTrain.mat','News20groupsTrain.mat','F194Train.mat','ILSVRC65Train.mat','SunTrain.mat','Cifar100Train.mat','Car196Train.mat','EisenTrain.mat','DerisiTrain.mat','CellcycleTrain.mat','GaschTrain.mat'};
% str_test_name = {'BridgesTest.mat','DDTest.mat','CLEFTest.mat','VOCTest.mat','News20groupsTest.mat','F194Test.mat','ILSVRC65Test.mat','SunTest.mat','Cifar100Test.mat','Car196Test.mat','EisenTest.mat','DerisiTest.mat','CellcycleTest.mat','GaschTest.mat'};
% str_function_name = {'fs_result_','acc_result_','cd_result_'};
% alphaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% betaArr = [1, 0.5, 0.1, 0.05, 0.01, 0];
% str_classifier_arr = {'M-KNN','M-SVM','M-RF'};
% str_function_name_F = {'Acc_M','F_1','F_{LCA}','TIE'};
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% % selectNum = [0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2];
% for i = 7:9%length(str_mat_name)
%     if(i == 2 || i == 3 || i == 4 || i == 5 || i == 6)
%         continue;
%     end
%     if(i == 1 || i == 8) % Bridges % Sun ��Ҫ
%         continue;
%     end
%     
%     %Bridges (alphaArr_i == 3 && betaArr_i == 4)
%     %ILSVRC65 (alphaArr_i == 5 && betaArr_i == 1) ok
%     %Sun (alphaArr_i == 5 && betaArr_i == 1)
%     %Cifar100 (alphaArr_i == 5 && betaArr_i == 1)  ok
%     
%     %Eisen (alphaArr_i == 2 && betaArr_i == 2)    ok
%     %Derisi (alphaArr_i == 2 && betaArr_i == 2)   ok
%     %Cellcycle (alphaArr_i == 2 && betaArr_i == 2)
%     %Gasch (alphaArr_i == 5 && betaArr_i == 5)
%     
%     %%%% ����ı�
%     str_classifier = str_classifier_arr{1};
%     str_function_F = str_function_name_F{2};
%     
%     selectNumPersen = [0.1, 0.2, 0.3, 0.4, 0.5, 1];
%     x = [1,2,3,4,5,6]; % x�������
%     xLables = ['10%' ; '20%'; '30%'; '40%'; '50%'; 'All'];
%     
%     dataCell = [];
%     for j = 1:length(selectNumPersen)
%         dataArr = [0,0,0];
%         
%         for alphaArr_i = 1:length(alphaArr)
%             for betaArr_i = 1:length(betaArr)
%                 
%                 if ((alphaArr_i == 5 && betaArr_i == 1) || (alphaArr_i == 5 && betaArr_i == 6) || (alphaArr_i == 6 && betaArr_i == 1))
%                     %0 load
%                     mat_name = [str_function_name{2}, algorithmName, '_', str_data_name{i}, '_alpha', int2str(alphaArr_i), '_beta', int2str(betaArr_i), '_', int2str(j)];
%                     mat_name_data = load (mat_name);
%                     
%                     %%%% ����ı�
%                     %(mat_name_data.vF_LCA_KNN + mat_name_data.vF_LCA_SVM + mat_name_data.vF_LCA_RF) / length(str_classifier_arr);
%                     data = mat_name_data.vF_1_KNN;
%                     
%                     %data = (mat_name_data.vF_LCA_KNN + mat_name_data.vF_LCA_SVM + mat_name_data.vF_LCA_RF) / length(str_classifier_arr);
%                     if (alphaArr_i == 5 && betaArr_i == 1)
%                         dataArr(1) = data;
%                     end
%                     if(alphaArr_i == 5 && betaArr_i == 6)
%                         dataArr(2) = data;
%                     end
%                     if(alphaArr_i == 6 && betaArr_i == 1)
%                         dataArr(3) = data;
%                     end
%                 end
%                 
%             end
%         end
%         dataCell = [dataCell; dataArr];
%     end
%     
%     legendName = ["MFSIP(��,��)","MFSIP(��)","MFSIP(��)"];
% 
%     % x����
%     XX = dataCell; %[1,3.92,2.78;1,6.63,4.2;9.98,22.15,15.46;9.98,22.15,15.46;9.98,22.15,15.46;9.98,22.15,15.46];
% 
%     figure1 = figure(1);
% 
%     %1 ��
%     h = bar(XX, 'FaceColor', 'flat');
%     mycolor = [155,127,160;205,150,155;200,200,227]./255;
%     for k = 1:size(XX,2)
%         h(k).FaceColor = mycolor(k,:);
%     end
%     
%     FontSize = 24;
%     set(gca, 'XTick', x, 'XTickLabel', xLables);
%     set(gca,'FontSize',FontSize,'Fontname', 'Times New Roman');
%     
%     if(i == 7)
%         aaa = 85;
%     else
%         aaa = 85;
%     end
%     max_y = max(max(dataCell));
%     min_y = min(min(dataCell));
%     max1 = aaa*max_y;
%     min1 = aaa*min_y;
%     ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
%     
%     str = "123";
%     if(i == 7)
%         str = "Number of features (a)";
%     else
%         str = "Number of features (b)";
%     end
%     xlabel(str,'Fontname', 'Times New Roman','FontSize',FontSize);
%     ylabel([str_function_F,'(', str_classifier,')'],'Fontname', 'Times New Roman','FontSize',FontSize);
%     %ylabel([str_function_F,'(', str_classifier,')'],'Fontname', 'Times New Roman','FontSize',FontSize);
% 
% %     hl = legend(legendName);
% %     set(hl,'Orientation','horizon');
% %     set(hl,'Box','on', 'location','NorthEast', 'FontSize',FontSize, 'FontName','Times New Roman');    
%     ax1 = gca;
%     %ax1.LineWidth = 1;
% 
%     fileName_result = [int2str(2), '_', algorithmName, '_', str_classifier, '_', str_function_F, '_fig_', str_data_name{i}];
%     saveas(figure1, strcat([filePath, fileName_result], '.png')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
%     close(figure1);
% end

%% ʱ�临�Ӷ�����
%% ʱ�临�Ӷ�����+ͼ�ṹ
% clc;
% clear;
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% arrCell = [1/16.0110 ,1/15.4380 ,1/20.2120 ,1/11.0940 ;...
%     1/70.8620 ,1/18.2710 ,1/18.6640 ,1/10.1890 ;...
%     1/76.5410 ,1/71.9930 ,1/86.0620 ,1/58.4310 ;...
%     1/10189.0000 ,1/14646.0000 ,1/18056.0000 ,1/12071.0000 ;...
%     1/7483.6000 ,1/13868.0000 ,1/17321.0000 ,1/11601.0000 ;...
%     1/0.6584 ,1/0.6809 ,1/0.7989 ,1/0.3876 ];
% x = [1,2,3,4,5,6]; % x�������
% xLables = ["DFSCS";"DDFS";"DFisher";"DFSWOA";"DFSSCA";"MFSIP"];
% 
% legendName = ["Eisen","Derisi","Cellcycle","Gasch"];
% 
% % x����
% XX = arrCell; %[1,3.92,2.78;1,6.63,4.2;9.98,22.15,15.46;9.98,22.15,15.46;9.98,22.15,15.46;9.98,22.15,15.46];
% 
% figure1 = figure(1);
% 
% %1 ��
% h = bar(XX, 'FaceColor', 'flat');
% mycolor = [102,128,255;255,179,102;255,255,153;255,255,255]./255;
% for k = 1:size(XX,2)
%     h(k).FaceColor = mycolor(k,:);
% end
% 
% FontSize = 24;
% set(gca, 'XTick', x, 'XTickLabel', xLables);
% set(gca,'FontSize',FontSize,'Fontname', 'Times New Roman');
% aaa = 95;
% max_y = max(max(arrCell));
% min_y = min(min(arrCell));
% max1 = aaa*max_y;
% min1 = aaa*min_y;
% ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)+0.5]); %y��̶�
% 
% xlabel("Methods",'Fontname', 'Times New Roman','FontSize',FontSize);
% ylabel("1/R\_Time",'Fontname', 'Times New Roman','FontSize',FontSize);
% %ylabel([str_function_F,'(', str_classifier,')'],'Fontname', 'Times New Roman','FontSize',FontSize);
% 
% hl = legend(legendName);
% set(hl,'Orientation','horizon');
% set(hl,'Box','on', 'location','NorthEast', 'FontSize',FontSize, 'FontName','Times New Roman');    
% ax1 = gca;
% %ax1.LineWidth = 1;
% 
% fileName_result = [algorithmName, '_fig_', 'DAG'];
% saveas(figure1, strcat([filePath, fileName_result], '.png')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
% close(figure1);

%% ʱ�临�Ӷ�����+���ṹ
% clc;
% clear;
% 
% algorithmName = 'MFSIP';
% filePath = '/Users/lindashuai/Documents/MATLAB/NoteOfMatlab/MFSIPMain/result/0MFSIP/';
% % filePath = 'D:\Matlab\MFSIPMain\result\0MFSIP\';
% 
% % arrCell = [0.001/0.0642 ,1/12177.0000 ,1/39750.0000 ,1/22623.0000 ;...
% %     0.001/0.0133 ,1/388.4800 ,1/2185.3000 ,1/9709.8000 ;...
% %     0.001/0.0166 ,1/70.1260 ,1/343.5300 ,1/404.1000 ;...
% %     0.001/0.0696 ,1/292.0800 ,1/936.9600 ,1/893.3000 ;...
% %     0.001/0.3553 ,1/1712.9000 ,1/6216.6000 ,1/5798.3000 ;...
% %     0.001/0.0154 ,1/172.8800 ,1/449.3800 ,1/538.0900 ;...
% %     0.001/0.5989 ,1/1177.3000 ,1/2133.2000 ,1/786.6500 ;...
% %     0.001/0.0022 ,1/161.1300 ,1/553.8000 ,1/432.3000 ];
% arrCell = [1/12177.0000 ,1/39750.0000 ,1/22623.0000 ;...
%     1/388.4800 ,1/2185.3000 ,1/9709.8000 ;...
%     1/70.1260 ,1/343.5300 ,1/404.1000 ;...
%     1/292.0800 ,1/936.9600 ,1/893.3000 ;...
%     1/1712.9000 ,1/6216.6000 ,1/5798.3000 ;...
%     1/172.8800 ,1/449.3800 ,1/538.0900 ;...
%     1/1177.3000 ,1/2133.2000 ,1/786.6500 ;...
%     1/161.1300 ,1/553.8000 ,1/432.3000 ];
% x = [1,2,3,4,5,6,7,8]; % x�������
% xLables = ["TFSGK";"TFSfam";"TFSLDL";"TFSCN";"TFSDK";"TFSGR";"TFSLE";"MFSIP"];
% 
% legendName = ["ILSVRC57","SUN324","Cifar100"];
% 
% % x����
% XX = arrCell; %[1,3.92,2.78;1,6.63,4.2;9.98,22.15,15.46;9.98,22.15,15.46;9.98,22.15,15.46;9.98,22.15,15.46];
% 
% figure1 = figure(1);
% 
% %1 ��
% FontSize = 24;
% h = bar(XX, 'FaceColor', 'flat');
% mycolor = [255,179,102;255,255,153;255,255,255]./255;
% for k = 1:size(XX,2)
%     h(k).FaceColor = mycolor(k,:);
% end
% 
% set(gca, 'XTick', x, 'XTickLabel', xLables);
% set(gca,'FontSize',FontSize,'Fontname', 'Times New Roman');
% aaa = 50;
% max_y = max(max(arrCell));
% min_y = min(min(arrCell));
% max1 = aaa*max_y;
% min1 = aaa*min_y;
% ylim([floor(min1)*(1/aaa),ceil(max1)*(1/aaa)]); %y��̶�
% 
% xlabel("Methods",'Fontname', 'Times New Roman','FontSize',FontSize);
% ylabel("1/R\_Time",'Fontname', 'Times New Roman','FontSize',FontSize);
% %ylabel([str_function_F,'(', str_classifier,')'],'Fontname', 'Times New Roman','FontSize',FontSize);
% 
% hl = legend(legendName);
% set(hl,'Orientation','horizon');
% set(hl,'Box','on', 'location','NorthEast', 'FontSize',FontSize, 'FontName','Times New Roman');    
% ax1 = gca;
% %ax1.LineWidth = 1;
% 
% fileName_result = [algorithmName, '_fig_', 'Tree'];
% saveas(figure1, strcat([filePath, fileName_result], '.png')); % saveas(fg, strcat([filePath, fileName], '.pdf'));
% close(figure1);
% 
